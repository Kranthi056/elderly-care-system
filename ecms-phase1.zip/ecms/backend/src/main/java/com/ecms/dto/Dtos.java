package com.ecms.dto;

import com.ecms.model.Role;
import com.ecms.model.VerificationStatus;
import jakarta.validation.constraints.*;
import java.time.LocalDate;

public final class Dtos {
    private Dtos() {}

    public record OtpRequest(@NotBlank @Pattern(regexp = "^\\d{10}$", message = "Enter a valid 10-digit mobile number") String mobile) {}

    public record OtpResponse(boolean mock, String message, String mockOtp, int expiresInSeconds) {}

    public record RegisterRequest(
            @NotNull Role role,
            @NotBlank @Size(min = 2, max = 120) String fullName,
            @NotBlank @Pattern(regexp = "^\\d{10}$", message = "Enter a valid 10-digit mobile number") String mobile,
            @Email String email,
            @NotBlank @Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[^A-Za-z0-9]).{8,64}$",
                    message = "Password needs 8+ characters with upper, lower, number and symbol") String password,
            String gender,
            @NotNull @Past LocalDate dateOfBirth,
            @NotBlank @Size(max = 255) String address,
            @NotBlank @Size(max = 80) String city,
            @NotBlank @Size(max = 80) String state,
            @NotBlank @Pattern(regexp = "^\\d{6}$", message = "PIN code must be 6 digits") String pinCode,
            @NotBlank String otp,
            @AssertTrue(message = "You must accept the Terms and Privacy Policy") boolean consent) {}

    public record LoginRequest(
            @NotBlank String identifier,
            @NotBlank String password,
            boolean remember) {}

    public record UserView(Long id, String fullName, String mobile, String email, Role role,
                           VerificationStatus verificationStatus) {}

    public record AuthResponse(String token, UserView user, String redirectTo, String notice) {}

    public record ContactRequestDto(
            @NotBlank @Size(max = 120) String name,
            @NotBlank @Pattern(regexp = "^\\d{10}$", message = "Enter a valid 10-digit mobile number") String mobile,
            @Email String email,
            @Size(max = 2000) String message) {}

    public record ApiError(String error, String message) {}
}
