package com.ecms.web;

import com.ecms.dto.Dtos.*;
import com.ecms.model.AppUser;
import com.ecms.model.Role;
import com.ecms.service.AuthService;
import com.ecms.service.OtpService;
import jakarta.validation.Valid;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final AuthService auth;
    private final OtpService otp;

    public AuthController(AuthService auth, OtpService otp) {
        this.auth = auth;
        this.otp = otp;
    }

    @PostMapping("/otp/send")
    public OtpResponse sendOtp(@Valid @RequestBody OtpRequest r) { return otp.send(r.mobile()); }

    @PostMapping("/register")
    public AuthResponse register(@Valid @RequestBody RegisterRequest r) { return auth.register(r); }

    /** Shared portal: Direct Users and Monitoring Persons only. */
    @PostMapping("/login")
    public AuthResponse login(@Valid @RequestBody LoginRequest r) {
        return auth.login(r, Set.of(Role.DIRECT_USER, Role.MONITORING_PERSON));
    }

    @PostMapping("/caregiver/login")
    public AuthResponse caregiverLogin(@Valid @RequestBody LoginRequest r) {
        return auth.login(r, Set.of(Role.CAREGIVER));
    }

    @PostMapping("/admin/login")
    public AuthResponse adminLogin(@Valid @RequestBody LoginRequest r) {
        return auth.login(r, Set.of(Role.ADMIN));
    }

    @GetMapping("/me")
    public UserView me(@AuthenticationPrincipal AppUser u) { return AuthService.view(u); }
}
