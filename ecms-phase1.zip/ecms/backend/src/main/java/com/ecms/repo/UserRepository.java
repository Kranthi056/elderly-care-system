package com.ecms.repo;

import com.ecms.model.AppUser;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface UserRepository extends JpaRepository<AppUser, Long> {
    Optional<AppUser> findByMobile(String mobile);
    Optional<AppUser> findFirstByEmailIgnoreCase(String email);
    boolean existsByMobile(String mobile);
}
