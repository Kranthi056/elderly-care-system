package com.ecms.model;

public enum Role { DIRECT_USER, MONITORING_PERSON, CAREGIVER, ADMIN }
