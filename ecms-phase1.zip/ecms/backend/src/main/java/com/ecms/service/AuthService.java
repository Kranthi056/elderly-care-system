package com.ecms.service;

import com.ecms.dto.Dtos.*;
import com.ecms.model.AppUser;
import com.ecms.model.Role;
import com.ecms.model.VerificationStatus;
import com.ecms.repo.UserRepository;
import com.ecms.security.JwtService;
import com.ecms.web.ApiException;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class AuthService {
    private static final Set<Role> SHARED_PORTAL = Set.of(Role.DIRECT_USER, Role.MONITORING_PERSON);
    private static final int MAX_FAILS = 5;
    private static final long LOCK_SECONDS = 300;

    private record Fail(int count, Instant lockedUntil) {}

    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final JwtService jwt;
    private final OtpService otp;
    private final ConcurrentHashMap<String, Fail> fails = new ConcurrentHashMap<>();

    public AuthService(UserRepository users, PasswordEncoder encoder, JwtService jwt, OtpService otp) {
        this.users = users;
        this.encoder = encoder;
        this.jwt = jwt;
        this.otp = otp;
    }

    /** Where each role lands after authentication. Decided by the server from the stored role. */
    public static String redirectFor(AppUser u) {
        return switch (u.getRole()) {
            case DIRECT_USER -> "/user/dashboard";
            case MONITORING_PERSON -> "/family/dashboard";
            case CAREGIVER -> "/caregiver/dashboard";
            case ADMIN -> "/admin/dashboard";
        };
    }

    public static UserView view(AppUser u) {
        return new UserView(u.getId(), u.getFullName(), u.getMobile(), u.getEmail(), u.getRole(), u.getVerificationStatus());
    }

    @Transactional
    public AuthResponse register(RegisterRequest r) {
        if (!SHARED_PORTAL.contains(r.role())) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "ROLE_NOT_ALLOWED", "Only elderly users and family members can register here.");
        }
        if (users.existsByMobile(r.mobile())) {
            throw new ApiException(HttpStatus.CONFLICT, "MOBILE_EXISTS", "This mobile number is already registered. Please sign in.");
        }
        otp.verifyAndConsume(r.mobile(), r.otp());

        AppUser u = new AppUser();
        u.setRole(r.role());
        u.setFullName(r.fullName().trim());
        u.setMobile(r.mobile());
        u.setEmail(r.email() == null || r.email().isBlank() ? null : r.email().trim().toLowerCase());
        u.setPasswordHash(encoder.encode(r.password()));
        u.setGender(r.gender());
        u.setDateOfBirth(r.dateOfBirth());
        u.setAddress(r.address());
        u.setCity(r.city());
        u.setState(r.state());
        u.setPinCode(r.pinCode());
        users.save(u);

        String notice = r.role() == Role.MONITORING_PERSON
                ? "Your account has been created. To monitor an elderly person's care, you must first connect to their profile and obtain the required authorisation."
                : "Your account has been created. Welcome to ECMS.";
        return new AuthResponse(jwt.issue(u, false), view(u), redirectFor(u), notice);
    }

    public AuthResponse login(LoginRequest r, Set<Role> allowedRoles) {
        String key = r.identifier().trim().toLowerCase();
        Fail f = fails.get(key);
        if (f != null && f.lockedUntil() != null && f.lockedUntil().isAfter(Instant.now())) {
            throw new ApiException(HttpStatus.TOO_MANY_REQUESTS, "LOCKED",
                    "Too many failed attempts. Please try again in a few minutes.");
        }
        AppUser u = find(key).orElse(null);
        // Same generic error for unknown user, wrong password, or wrong portal: no account enumeration.
        boolean ok = u != null && u.isEnabled() && allowedRoles.contains(u.getRole())
                && encoder.matches(r.password(), u.getPasswordHash());
        if (!ok) {
            int c = (f == null ? 0 : f.count()) + 1;
            fails.put(key, new Fail(c, c >= MAX_FAILS ? Instant.now().plusSeconds(LOCK_SECONDS) : null));
            throw new ApiException(HttpStatus.UNAUTHORIZED, "BAD_CREDENTIALS",
                    "We couldn't sign you in with those details. Please check them and try again.");
        }
        fails.remove(key);
        String notice = null;
        if (u.getRole() == Role.CAREGIVER && u.getVerificationStatus() != VerificationStatus.APPROVED) {
            notice = "Your account is awaiting hospital verification. Dashboard access will be activated after approval.";
        }
        return new AuthResponse(jwt.issue(u, r.remember()), view(u), redirectFor(u), notice);
    }

    private java.util.Optional<AppUser> find(String identifier) {
        return identifier.contains("@") ? users.findFirstByEmailIgnoreCase(identifier) : users.findByMobile(identifier);
    }
}
