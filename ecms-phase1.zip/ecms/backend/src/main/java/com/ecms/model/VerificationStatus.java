package com.ecms.model;

/** Caregiver hospital-verification state. Null for non-caregiver roles. */
public enum VerificationStatus { PENDING_VERIFICATION, APPROVED, REJECTED }
