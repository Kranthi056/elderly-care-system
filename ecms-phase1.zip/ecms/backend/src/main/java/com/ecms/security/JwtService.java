package com.ecms.security;

import com.ecms.model.AppUser;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.Optional;

@Service
public class JwtService {
    private final SecretKey key;
    private final Duration shortTtl;
    private final Duration longTtl;

    public JwtService(@Value("${ecms.jwt.secret}") String secret,
                      @Value("${ecms.jwt.expiry-minutes}") long minutes,
                      @Value("${ecms.jwt.remember-expiry-days}") long days) {
        if (secret.length() < 32) throw new IllegalStateException("ecms.jwt.secret must be at least 32 characters");
        this.key = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
        this.shortTtl = Duration.ofMinutes(minutes);
        this.longTtl = Duration.ofDays(days);
    }

    public String issue(AppUser u, boolean remember) {
        Instant now = Instant.now();
        return Jwts.builder()
                .subject(String.valueOf(u.getId()))
                .claim("role", u.getRole().name())
                .issuedAt(Date.from(now))
                .expiration(Date.from(now.plus(remember ? longTtl : shortTtl)))
                .signWith(key)
                .compact();
    }

    /** @return user id, or empty if the token is invalid/expired. */
    public Optional<Long> parseUserId(String token) {
        try {
            Claims c = Jwts.parser().verifyWith(key).build().parseSignedClaims(token).getPayload();
            return Optional.of(Long.parseLong(c.getSubject()));
        } catch (JwtException | IllegalArgumentException e) {
            return Optional.empty();
        }
    }
}
