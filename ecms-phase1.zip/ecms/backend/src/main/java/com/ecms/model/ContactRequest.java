package com.ecms.model;

import jakarta.persistence.*;
import java.time.Instant;

/** "Talk to Us" enquiry from the public site. Admin handling comes in a later phase. */
@Entity
@Table(name = "contact_requests")
public class ContactRequest {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, length = 120) private String name;
    @Column(nullable = false, length = 15) private String mobile;
    @Column(length = 160) private String email;
    @Column(length = 2000) private String message;
    @Column(nullable = false, length = 20) private String status = "NEW";
    @Column(nullable = false) private Instant createdAt = Instant.now();

    public Long getId() { return id; }
    public String getName() { return name; }
    public void setName(String v) { this.name = v; }
    public String getMobile() { return mobile; }
    public void setMobile(String v) { this.mobile = v; }
    public String getEmail() { return email; }
    public void setEmail(String v) { this.email = v; }
    public String getMessage() { return message; }
    public void setMessage(String v) { this.message = v; }
    public String getStatus() { return status; }
    public void setStatus(String v) { this.status = v; }
    public Instant getCreatedAt() { return createdAt; }
}
