package com.ecms.web;

import com.ecms.model.AppUser;
import com.ecms.model.Role;
import com.ecms.model.VerificationStatus;
import com.ecms.repo.ContactRequestRepository;
import com.ecms.repo.UserRepository;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Phase 1 dashboard landing data. Each route is role-protected in SecurityConfig.
 * No real appointments, payments or medical records exist yet, so lists are intentionally empty.
 */
@RestController
public class DashboardController {
    private final UserRepository users;
    private final ContactRequestRepository contacts;

    public DashboardController(UserRepository users, ContactRequestRepository contacts) {
        this.users = users;
        this.contacts = contacts;
    }

    @GetMapping("/api/direct/dashboard")
    public Map<String, Object> direct(@AuthenticationPrincipal AppUser u) {
        return Map.of(
                "name", u.getFullName(),
                "upcomingAppointments", List.of(),
                "todaysTasks", List.of(),
                "pendingRequests", List.of(),
                "recentCareUpdates", List.of());
    }

    @GetMapping("/api/monitoring/dashboard")
    public Map<String, Object> monitoring(@AuthenticationPrincipal AppUser u) {
        // Linking is a later phase. No automatic links, so no elderly data is ever returned here.
        return Map.of(
                "name", u.getFullName(),
                "linkStatus", "NOT_LINKED",
                "linkedElderly", List.of(),
                "upcomingAppointments", List.of(),
                "todaysCareSchedule", List.of(),
                "recentUpdates", List.of());
    }

    @GetMapping("/api/caregiver/dashboard")
    public Map<String, Object> caregiver(@AuthenticationPrincipal AppUser u) {
        boolean approved = u.getVerificationStatus() == VerificationStatus.APPROVED;
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("name", u.getFullName());
        m.put("verificationStatus", u.getVerificationStatus());
        m.put("active", approved);
        // Unverified caregivers get status only; no bookings or patient information.
        if (approved) {
            m.put("requests", List.of());
            m.put("schedule", List.of());
        }
        return m;
    }

    @GetMapping("/api/admin/dashboard")
    public Map<String, Object> admin(@AuthenticationPrincipal AppUser u) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("name", u.getFullName());
        m.put("directUsers", users.findAll().stream().filter(x -> x.getRole() == Role.DIRECT_USER).count());
        m.put("monitoringPersons", users.findAll().stream().filter(x -> x.getRole() == Role.MONITORING_PERSON).count());
        m.put("caregivers", users.findAll().stream().filter(x -> x.getRole() == Role.CAREGIVER).count());
        m.put("talkToUsRequests", contacts.count());
        return m;
    }
}
