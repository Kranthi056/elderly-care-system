package com.ecms.web;

import com.ecms.dto.Dtos.ContactRequestDto;
import com.ecms.model.ContactRequest;
import com.ecms.repo.ContactRequestRepository;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class PublicController {
    private final ContactRequestRepository contacts;

    public PublicController(ContactRequestRepository contacts) { this.contacts = contacts; }

    @GetMapping("/health")
    public Map<String, String> health() { return Map.of("status", "UP"); }

    @PostMapping("/public/contact")
    public Map<String, String> contact(@Valid @RequestBody ContactRequestDto d) {
        ContactRequest c = new ContactRequest();
        c.setName(d.name().trim());
        c.setMobile(d.mobile());
        c.setEmail(d.email());
        c.setMessage(d.message());
        contacts.save(c);
        return Map.of("message", "Thank you. Our team will contact you soon.");
    }
}
