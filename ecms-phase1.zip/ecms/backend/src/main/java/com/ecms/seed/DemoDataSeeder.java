package com.ecms.seed;

import com.ecms.model.AppUser;
import com.ecms.model.Role;
import com.ecms.model.VerificationStatus;
import com.ecms.repo.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

/**
 * DEVELOPMENT ONLY. Seeds demo accounts when ecms.seed-demo=true (default for local runs, false under the
 * "prod" profile). Passwords are stored as BCrypt hashes. Change or remove before any real-world use.
 */
@Component
@ConditionalOnProperty(name = "ecms.seed-demo", havingValue = "true")
public class DemoDataSeeder implements ApplicationRunner {
    private static final Logger log = LoggerFactory.getLogger(DemoDataSeeder.class);
    private final UserRepository users;
    private final PasswordEncoder encoder;

    public DemoDataSeeder(UserRepository users, PasswordEncoder encoder) {
        this.users = users;
        this.encoder = encoder;
    }

    @Override
    public void run(ApplicationArguments args) {
        seed("Asha Raman", "9000000001", "user.demo@ecms.test", "ECMS@User123", Role.DIRECT_USER, null, LocalDate.of(1950, 4, 12));
        seed("Rahul Raman", "9000000002", "family.demo@ecms.test", "ECMS@Family123", Role.MONITORING_PERSON, null, LocalDate.of(1982, 9, 3));
        seed("Meera Nair", "9000000003", "caregiver.demo@ecms.test", "ECMS@Care123", Role.CAREGIVER, VerificationStatus.APPROVED, LocalDate.of(1990, 1, 20));
        seed("Pending Caregiver", "9000000004", "caregiver.pending@ecms.test", "ECMS@Pending123", Role.CAREGIVER, VerificationStatus.PENDING_VERIFICATION, LocalDate.of(1992, 6, 8));
        seed("ECMS Administrator", "9000000005", "admin.demo@ecms.test", "ECMS@Admin123", Role.ADMIN, null, LocalDate.of(1985, 2, 2));
        log.warn("DEMO ACCOUNTS SEEDED (development only). Disable with ecms.seed-demo=false.");
    }

    private void seed(String name, String mobile, String email, String pw, Role role, VerificationStatus vs, LocalDate dob) {
        if (users.findFirstByEmailIgnoreCase(email).isPresent() || users.existsByMobile(mobile)) return;
        AppUser u = new AppUser();
        u.setFullName(name);
        u.setMobile(mobile);
        u.setEmail(email);
        u.setPasswordHash(encoder.encode(pw));
        u.setRole(role);
        u.setVerificationStatus(vs);
        u.setDateOfBirth(dob);
        u.setCity("Demo City");
        u.setState("Demo State");
        u.setAddress("Demo address (seed data)");
        u.setPinCode("600001");
        users.save(u);
    }
}
