package com.ecms.service;

import com.ecms.dto.Dtos.OtpResponse;
import com.ecms.web.ApiException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.security.SecureRandom;
import java.time.Instant;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Mobile OTP. Only MOCK mode is implemented in Phase 1: no SMS provider is configured, so the code is
 * returned in the API response and clearly labelled as such. Replace {@link #send} with a real SMS gateway later.
 */
@Service
public class OtpService {
    private record Entry(String code, Instant expires, Instant sentAt, int attempts) {}

    private final ConcurrentHashMap<String, Entry> store = new ConcurrentHashMap<>();
    private final SecureRandom random = new SecureRandom();
    private final boolean mock;
    private final int ttl;

    public OtpService(@Value("${ecms.otp.mock}") boolean mock, @Value("${ecms.otp.ttl-seconds}") int ttl) {
        this.mock = mock;
        this.ttl = ttl;
    }

    public OtpResponse send(String mobile) {
        if (!mock) {
            throw new ApiException(HttpStatus.NOT_IMPLEMENTED, "OTP_UNAVAILABLE",
                    "No SMS provider is configured. OTP delivery is unavailable.");
        }
        Entry prev = store.get(mobile);
        if (prev != null && prev.sentAt().plusSeconds(15).isAfter(Instant.now())) {
            throw new ApiException(HttpStatus.TOO_MANY_REQUESTS, "OTP_COOLDOWN", "Please wait a few seconds before requesting another OTP.");
        }
        String code = String.format("%06d", random.nextInt(1_000_000));
        Instant now = Instant.now();
        store.put(mobile, new Entry(code, now.plusSeconds(ttl), now, 0));
        return new OtpResponse(true,
                "DEVELOPMENT MOCK OTP MODE: no SMS was sent. Use the code shown below.", code, ttl);
    }

    /** Verifies and consumes the OTP. */
    public void verifyAndConsume(String mobile, String otp) {
        Entry e = store.get(mobile);
        if (e == null || e.expires().isBefore(Instant.now())) {
            store.remove(mobile);
            throw new ApiException(HttpStatus.BAD_REQUEST, "OTP_INVALID", "The OTP has expired. Please request a new one.");
        }
        if (e.attempts() >= 5) {
            store.remove(mobile);
            throw new ApiException(HttpStatus.TOO_MANY_REQUESTS, "OTP_LOCKED", "Too many wrong attempts. Please request a new OTP.");
        }
        if (!e.code().equals(otp)) {
            store.put(mobile, new Entry(e.code(), e.expires(), e.sentAt(), e.attempts() + 1));
            throw new ApiException(HttpStatus.BAD_REQUEST, "OTP_INVALID", "That OTP is not correct. Please try again.");
        }
        store.remove(mobile);
    }
}
