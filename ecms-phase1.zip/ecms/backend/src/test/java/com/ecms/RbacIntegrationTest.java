package com.ecms;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class RbacIntegrationTest {
    @Autowired MockMvc mvc;
    @Autowired ObjectMapper mapper;

    private String login(String path, String id, String pw) throws Exception {
        String body = "{\"identifier\":\"" + id + "\",\"password\":\"" + pw + "\"}";
        String res = mvc.perform(post(path).contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        JsonNode n = mapper.readTree(res);
        return n.get("token").asText();
    }

    private void expect(String url, String token, int code) throws Exception {
        var req = get(url);
        if (token != null) req = req.header("Authorization", "Bearer " + token);
        mvc.perform(req).andExpect(status().is(code));
    }

    @Test
    void rolesAreEnforcedOnEveryDashboard() throws Exception {
        String user = login("/api/auth/login", "user.demo@ecms.test", "ECMS@User123");
        String family = login("/api/auth/login", "family.demo@ecms.test", "ECMS@Family123");
        String care = login("/api/auth/caregiver/login", "caregiver.demo@ecms.test", "ECMS@Care123");
        String admin = login("/api/auth/admin/login", "admin.demo@ecms.test", "ECMS@Admin123");

        String[][] matrix = {
            {"/api/direct/dashboard"}, {"/api/monitoring/dashboard"}, {"/api/caregiver/dashboard"}, {"/api/admin/dashboard"}};
        String[] tokens = {user, family, care, admin};
        for (int u = 0; u < 4; u++) {
            for (int d = 0; d < 4; d++) expect(matrix[d][0], tokens[u], u == d ? 200 : 403);
        }
        for (String[] m : matrix) expect(m[0], null, 401);
    }

    @Test
    void wrongPortalAndBadPasswordAreRejected() throws Exception {
        String bad = "{\"identifier\":\"admin.demo@ecms.test\",\"password\":\"ECMS@Admin123\"}";
        mvc.perform(post("/api/auth/login").contentType(MediaType.APPLICATION_JSON).content(bad)).andExpect(status().isUnauthorized());
        String wrongPw = "{\"identifier\":\"user.demo@ecms.test\",\"password\":\"nope\"}";
        mvc.perform(post("/api/auth/login").contentType(MediaType.APPLICATION_JSON).content(wrongPw)).andExpect(status().isUnauthorized());
    }

    @Test
    void pendingCaregiverSeesNoWorkspaceData() throws Exception {
        String t = login("/api/auth/caregiver/login", "caregiver.pending@ecms.test", "ECMS@Pending123");
        mvc.perform(get("/api/caregiver/dashboard").header("Authorization", "Bearer " + t))
                .andExpect(status().isOk()).andExpect(jsonPath("$.active").value(false)).andExpect(jsonPath("$.requests").doesNotExist());
    }

    @Test
    void registrationRequiresValidOtpAndRejectsPrivilegedRoles() throws Exception {
        String otpRes = mvc.perform(post("/api/auth/otp/send").contentType(MediaType.APPLICATION_JSON).content("{\"mobile\":\"9333333333\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        String otp = mapper.readTree(otpRes).get("mockOtp").asText();
        String base = "\"fullName\":\"Test Person\",\"mobile\":\"9333333333\",\"password\":\"Abcd@1234\",\"dateOfBirth\":\"1960-01-01\","
                + "\"address\":\"a\",\"city\":\"c\",\"state\":\"s\",\"pinCode\":\"600001\",\"consent\":true,";
        mvc.perform(post("/api/auth/register").contentType(MediaType.APPLICATION_JSON)
                .content("{" + base + "\"role\":\"ADMIN\",\"otp\":\"" + otp + "\"}")).andExpect(status().isBadRequest());
        mvc.perform(post("/api/auth/register").contentType(MediaType.APPLICATION_JSON)
                .content("{" + base + "\"role\":\"DIRECT_USER\",\"otp\":\"000000x\"}")).andExpect(status().isBadRequest());
        mvc.perform(post("/api/auth/register").contentType(MediaType.APPLICATION_JSON)
                .content("{" + base + "\"role\":\"MONITORING_PERSON\",\"otp\":\"" + otp + "\"}"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.redirectTo").value("/family/dashboard"));
    }
}
