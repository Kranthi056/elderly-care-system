import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
import './styles/theme.css';
import App from './App.jsx';
import { AuthProvider } from './auth/AuthContext.jsx';
import { TalkToUsProvider } from './components/TalkToUs.jsx';

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <AuthProvider>
        <TalkToUsProvider>
          <App />
        </TalkToUsProvider>
      </AuthProvider>
    </BrowserRouter>
  </React.StrictMode>,
);
