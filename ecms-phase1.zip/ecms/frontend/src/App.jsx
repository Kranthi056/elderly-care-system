import { Navigate, Route, Routes } from 'react-router-dom';
import ProtectedRoute from './auth/ProtectedRoute.jsx';
import Home from './pages/public/Home.jsx';
import { NotFound, AccessDenied, ForgotPassword, Privacy, Terms } from './pages/public/Misc.jsx';
import UserSignIn from './pages/auth/UserSignIn.jsx';
import SignUp from './pages/auth/SignUp.jsx';
import CaregiverLogin from './pages/auth/CaregiverLogin.jsx';
import AdminLogin from './pages/auth/AdminLogin.jsx';
import DirectDashboard from './pages/dashboards/DirectDashboard.jsx';
import MonitoringDashboard from './pages/dashboards/MonitoringDashboard.jsx';
import CaregiverDashboard from './pages/dashboards/CaregiverDashboard.jsx';
import AdminDashboard from './pages/dashboards/AdminDashboard.jsx';
import DashboardLayout from './components/DashboardLayout.jsx';
import ModulePlaceholder from './components/ModulePlaceholder.jsx';
import { USER_MODULES, FAMILY_MODULES, CAREGIVER_MODULES, ADMIN_MODULES } from './components/modules.js';
import { useAuth } from './auth/AuthContext.jsx';

/** Registers /<base>/dashboard plus /<base>/:slug placeholder pages, all guarded by role. */
function portal(base, role, Dashboard, modules, portalName) {
  return [
    <Route key={`${base}-d`} path={`${base}/dashboard`} element={<ProtectedRoute roles={[role]}><Dashboard /></ProtectedRoute>} />,
    <Route key={`${base}-m`} path={`${base}/:slug`} element={
      <ProtectedRoute roles={[role]}><PortalPage base={base} modules={modules} portalName={portalName} /></ProtectedRoute>} />,
  ];
}

function PortalPage({ base, modules, portalName }) {
  const { user } = useAuth();
  // Unverified caregivers get no workspace pages at all
  const usable = user.role === 'CAREGIVER' && user.verificationStatus !== 'APPROVED' ? [] : modules;
  if (!usable.length) return <Navigate to={`${base}/dashboard`} replace />;
  return <DashboardLayout base={base} modules={modules} portalName={portalName}><ModulePlaceholder base={base} modules={modules} /></DashboardLayout>;
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/signin" element={<UserSignIn />} />
      <Route path="/signup" element={<SignUp />} />
      <Route path="/caregiver/login" element={<CaregiverLogin />} />
      <Route path="/admin/login" element={<AdminLogin />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/privacy" element={<Privacy />} />
      <Route path="/terms" element={<Terms />} />
      <Route path="/access-denied" element={<AccessDenied />} />
      {portal('/user', 'DIRECT_USER', DirectDashboard, USER_MODULES, 'Elderly User Portal')}
      {portal('/family', 'MONITORING_PERSON', MonitoringDashboard, FAMILY_MODULES, 'Family Portal')}
      {portal('/caregiver', 'CAREGIVER', CaregiverDashboard, CAREGIVER_MODULES, 'Caregiver Portal')}
      {portal('/admin', 'ADMIN', AdminDashboard, ADMIN_MODULES, 'Hospital Administration')}
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}
