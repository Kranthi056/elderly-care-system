import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext.jsx';
import PasswordInput from './PasswordInput.jsx';
import DevCredentials from './DevCredentials.jsx';

const CONFIG = {
  user: { idLabel: 'Registered Mobile Number (or Email)', idPlaceholder: '10-digit mobile number', btn: 'Sign In', remember: true,
    check: (v) => (/^\d{10}$/.test(v) || /^\S+@\S+\.\S+$/.test(v) ? '' : 'Enter your 10-digit mobile number or email address.') },
  caregiver: { idLabel: 'Registered Mobile Number or Email', idPlaceholder: 'Mobile number or email', btn: 'Caregiver Sign In', remember: true,
    check: (v) => (/^\d{10}$/.test(v) || /^\S+@\S+\.\S+$/.test(v) ? '' : 'Enter your 10-digit mobile number or email address.') },
  admin: { idLabel: 'Admin Email / Username', idPlaceholder: 'name@hospital.org', btn: 'Admin Sign In', remember: false,
    check: (v) => (v.trim().length >= 3 ? '' : 'Enter your admin email or username.') },
};

export default function LoginForm({ portal }) {
  const cfg = CONFIG[portal];
  const { signIn } = useAuth();
  const nav = useNavigate();
  const [f, setF] = useState({ identifier: '', password: '', remember: false });
  const [err, setErr] = useState({});
  const [busy, setBusy] = useState(false);
  const [serverErr, setServerErr] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    const er = {};
    const idErr = cfg.check(f.identifier.trim());
    if (idErr) er.identifier = idErr;
    if (!f.password) er.password = 'Please enter your password.';
    setErr(er); setServerErr('');
    if (Object.keys(er).length) return;
    setBusy(true);
    try {
      const res = await signIn(portal, { ...f, identifier: f.identifier.trim() });
      nav(res.redirectTo, { replace: true }); // destination comes from the authenticated account, not from the URL
    } catch (x) {
      setServerErr(x.message || 'Sign in failed.');
      setBusy(false);
    }
  };

  return (
    <form onSubmit={submit} noValidate>
      {serverErr && <div className="alert alert-danger d-flex gap-2 align-items-start" role="alert"><i className="bi bi-exclamation-circle-fill" />{serverErr}</div>}
      <div className="mb-3">
        <label htmlFor="identifier" className="form-label">{cfg.idLabel}</label>
        <input id="identifier" className={`form-control ${err.identifier ? 'is-invalid' : ''}`} value={f.identifier} autoComplete="username"
          placeholder={cfg.idPlaceholder} onChange={(e) => setF({ ...f, identifier: e.target.value })} />
        <div className="invalid-feedback">{err.identifier}</div>
      </div>
      <PasswordInput id="password" label="Password" value={f.password} error={err.password} autoComplete="current-password"
        onChange={(e) => setF({ ...f, password: e.target.value })} />
      <div className="d-flex justify-content-between align-items-center mb-4">
        {cfg.remember ? (
          <div className="form-check"><input id="remember" type="checkbox" className="form-check-input" checked={f.remember} onChange={(e) => setF({ ...f, remember: e.target.checked })} />
            <label htmlFor="remember" className="form-check-label">Remember me</label></div>
        ) : <span />}
        <Link to="/forgot-password" className="fw-bold small">Forgot Password?</Link>
      </div>
      <button className="btn btn-ecms w-100 btn-lg" disabled={busy}>
        {busy ? <><span className="spinner-border spinner-border-sm me-2" />Signing in…</> : cfg.btn}
      </button>
      <DevCredentials portal={portal} onFill={(identifier, password) => setF({ ...f, identifier, password })} />
    </form>
  );
}
