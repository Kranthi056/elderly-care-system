import { useState } from 'react';

export default function PasswordInput({ id, label, value, onChange, error, autoComplete, placeholder, onBlur }) {
  const [show, setShow] = useState(false);
  return (
    <div className="mb-3">
      <label htmlFor={id} className="form-label">{label}</label>
      <div className="position-relative">
        <input id={id} type={show ? 'text' : 'password'} className={`form-control pe-5 ${error ? 'is-invalid' : ''}`}
          value={value} onChange={onChange} onBlur={onBlur} autoComplete={autoComplete} placeholder={placeholder} />
        <button type="button" className="pw-toggle" onClick={() => setShow((s) => !s)} aria-label={show ? 'Hide password' : 'Show password'}>
          <i className={`bi ${show ? 'bi-eye-slash' : 'bi-eye'}`} />
        </button>
        {error && <div className="invalid-feedback d-block">{error}</div>}
      </div>
    </div>
  );
}
