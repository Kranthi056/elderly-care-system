import { Link } from 'react-router-dom';

export function ModuleTiles({ base, modules }) {
  return (
    <div className="row g-3">
      {modules.map((m, i) => (
        <div className="col-6 col-md-4 col-xl-3" key={m.slug}>
          <Link to={`${base}/${m.slug}`} className="tile">
            <div className={`icon-bubble mb-2 ${['ib-mint', 'ib-peach', 'ib-lav', 'ib-sage'][i % 4]}`}><i className={`bi ${m.icon}`} /></div>
            <div className="fw-bold lh-sm">{m.label}</div>
            <span className="later-badge mt-2 d-inline-block">Later phase</span>
          </Link>
        </div>))}
    </div>
  );
}

export function SummaryCard({ icon, title, empty, tone = 'ib-mint' }) {
  return (
    <div className="glass-card p-3 h-100">
      <div className="d-flex align-items-center gap-2 mb-2"><div className={`icon-bubble ${tone}`} style={{ width: 42, height: 42, fontSize: '1.2rem', borderRadius: 14 }}><i className={`bi ${icon}`} /></div>
        <h3 className="h6 mb-0">{title}</h3></div>
      <p className="small text-muted mb-0">{empty}</p>
    </div>
  );
}
