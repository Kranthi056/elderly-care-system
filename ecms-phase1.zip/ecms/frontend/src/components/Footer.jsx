import { Link } from 'react-router-dom';
import Logo from './Logo.jsx';

export default function Footer() {
  return (
    <footer className="ecms-footer">
      <div className="container">
        <div className="row g-4">
          <div className="col-lg-4">
            <Logo tagline />
            <p className="mt-3 small">Organising elderly care, connecting families and supporting trusted caregivers.</p>
          </div>
          <div className="col-6 col-lg-2">
            <h3 className="h6">Explore</h3>
            <ul className="list-unstyled small">
              <li><Link to="/#about">About ECMS</Link></li>
              <li><Link to="/signin">Family / User Portal</Link></li>
              <li><Link to="/caregiver/login">Caregiver Login</Link></li>
              <li><Link to="/admin/login">Admin Login</Link></li>
            </ul>
          </div>
          <div className="col-6 col-lg-3">
            <h3 className="h6">Contact (placeholders)</h3>
            <ul className="list-unstyled small">
              <li><i className="bi bi-telephone me-2" />+91 00000 00000</li>
              <li><i className="bi bi-envelope me-2" />care@ecms.example</li>
              <li><i className="bi bi-geo-alt me-2" />Hospital Campus, Your City</li>
            </ul>
          </div>
          <div className="col-lg-3">
            <h3 className="h6">Legal</h3>
            <ul className="list-unstyled small">
              <li><Link to="/privacy">Privacy Policy</Link></li>
              <li><Link to="/terms">Terms and Conditions</Link></li>
            </ul>
          </div>
        </div>
        <hr />
        <p className="small text-center mb-0">© {new Date().getFullYear()} Elderly Care Management System (ECMS). All rights reserved.</p>
      </div>
    </footer>
  );
}
