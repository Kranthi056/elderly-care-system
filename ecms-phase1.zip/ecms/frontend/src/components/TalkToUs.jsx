import { createContext, useContext, useEffect, useState } from 'react';
import { api } from '../api/client.js';

const Ctx = createContext({ open: () => {} });
export const useTalkToUs = () => useContext(Ctx);

export function TalkToUsProvider({ children }) {
  const [show, setShow] = useState(false);
  return (
    <Ctx.Provider value={{ open: () => setShow(true) }}>
      {children}
      {show && <Modal onClose={() => setShow(false)} />}
    </Ctx.Provider>
  );
}

function Modal({ onClose }) {
  const [f, setF] = useState({ name: '', mobile: '', email: '', message: '' });
  const [err, setErr] = useState({});
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState('');
  const [apiErr, setApiErr] = useState('');

  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => { document.removeEventListener('keydown', onKey); document.body.style.overflow = ''; };
  }, [onClose]);

  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const submit = async (e) => {
    e.preventDefault();
    const er = {};
    if (f.name.trim().length < 2) er.name = 'Please enter your name.';
    if (!/^\d{10}$/.test(f.mobile)) er.mobile = 'Enter a valid 10-digit mobile number.';
    if (f.email && !/^\S+@\S+\.\S+$/.test(f.email)) er.email = 'Enter a valid email or leave it blank.';
    setErr(er);
    if (Object.keys(er).length) return;
    setBusy(true); setApiErr('');
    try { setDone((await api('/public/contact', { method: 'POST', body: f })).message); }
    catch (x) { setApiErr(x.message); }
    finally { setBusy(false); }
  };

  return (
    <>
      <div className="modal-backdrop fade show" onClick={onClose} />
      <div className="modal fade show d-block" role="dialog" aria-modal="true" aria-labelledby="ttu-title" onClick={onClose}>
        <div className="modal-dialog modal-dialog-centered" onClick={(e) => e.stopPropagation()}>
          <div className="modal-content border-0" style={{ borderRadius: '1.5rem' }}>
            <div className="modal-header border-0 pb-0">
              <h2 className="h4 modal-title" id="ttu-title">Talk to Us</h2>
              <button type="button" className="btn-close" aria-label="Close" onClick={onClose} />
            </div>
            <div className="modal-body">
              {done ? (
                <div className="text-center py-3">
                  <div className="icon-bubble ib-mint mx-auto mb-3"><i className="bi bi-check2-circle" /></div>
                  <p className="fw-bold mb-1">{done}</p>
                  <p className="text-muted small">Phase 1 note: your request is saved; the full Care Guide workflow arrives in a later phase.</p>
                  <button className="btn btn-ecms" onClick={onClose}>Close</button>
                </div>
              ) : (
                <form onSubmit={submit} noValidate>
                  <p className="text-muted">Tell us a little about your family's needs and we'll get back to you.</p>
                  {apiErr && <div className="alert alert-danger py-2">{apiErr}</div>}
                  <div className="mb-3"><label className="form-label" htmlFor="ttu-name">Your name</label>
                    <input id="ttu-name" className={`form-control ${err.name ? 'is-invalid' : ''}`} value={f.name} onChange={set('name')} />
                    <div className="invalid-feedback">{err.name}</div></div>
                  <div className="row g-3 mb-3">
                    <div className="col-sm-6"><label className="form-label" htmlFor="ttu-mobile">Mobile number</label>
                      <input id="ttu-mobile" inputMode="numeric" maxLength={10} className={`form-control ${err.mobile ? 'is-invalid' : ''}`} value={f.mobile} onChange={set('mobile')} />
                      <div className="invalid-feedback">{err.mobile}</div></div>
                    <div className="col-sm-6"><label className="form-label" htmlFor="ttu-email">Email (optional)</label>
                      <input id="ttu-email" type="email" className={`form-control ${err.email ? 'is-invalid' : ''}`} value={f.email} onChange={set('email')} />
                      <div className="invalid-feedback">{err.email}</div></div>
                  </div>
                  <div className="mb-3"><label className="form-label" htmlFor="ttu-msg">How can we help? (optional)</label>
                    <textarea id="ttu-msg" rows={3} maxLength={2000} className="form-control" value={f.message} onChange={set('message')} /></div>
                  <button className="btn btn-ecms w-100" disabled={busy}>
                    {busy ? <><span className="spinner-border spinner-border-sm me-2" />Sending…</> : 'Send Request'}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
