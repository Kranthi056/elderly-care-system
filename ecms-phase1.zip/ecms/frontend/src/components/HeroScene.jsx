import { useRef } from 'react';
import Person from './Person.jsx';

const reduce = () => window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

/** Lightweight CSS-3D scene: preserve-3d layers, depth offsets, mouse tilt and floating motion. */
export default function HeroScene() {
  const ref = useRef(null);
  const move = (e) => {
    if (reduce() || !ref.current) return;
    const r = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
    ref.current.style.transform = `rotateY(${x * 14}deg) rotateX(${-y * 10}deg)`;
  };
  const leave = () => { if (ref.current) ref.current.style.transform = ''; };

  return (
    <div className="scene" onMouseMove={move} onMouseLeave={leave} role="img"
      aria-label="Illustration of an elderly person with a caregiver and a family member">
      <div className="scene-inner" ref={ref}>
        <div className="scene-plate" />
        <div className="scene-fig" style={{ left: '2%', top: '24%', '--z': '40px', animationDelay: '.4s' }}>
          <Person skin="#E8B890" hair="#5b4636" top="#319C91" bottom="#25796F" style="bun" accessory="cross" size={150} />
        </div>
        <div className="scene-fig" style={{ left: '30%', top: '30%', '--z': '90px' }}>
          <Person skin="#F2C9A5" hair="#E4E4E4" top="#F28C78" bottom="#FFD8C2" style="short" glasses accessory="cardigan" size={175} />
        </div>
        <div className="scene-fig" style={{ right: '2%', top: '24%', '--z': '60px', animationDelay: '.9s' }}>
          <Person skin="#D9A57E" hair="#33302c" top="#8e7bd0" bottom="#E9E1FA" style="short" size={150} />
        </div>
        <div className="scene-chip" style={{ left: '4%', top: '6%', '--z': '110px', transform: 'translateZ(110px)' }}><i className="bi bi-heart-fill" />Care Updates</div>
        <div className="scene-chip" style={{ right: '2%', top: '2%', animationDelay: '1s', transform: 'translateZ(130px)' }}><i className="bi bi-calendar2-check-fill text-teal" />Appointments</div>
        <div className="scene-chip" style={{ left: '30%', bottom: '4%', animationDelay: '.5s', transform: 'translateZ(100px)' }}><i className="bi bi-people-fill" style={{ color: 'var(--teal-deep)' }} />Family Connected</div>
      </div>
    </div>
  );
}
