import { Link, useParams } from 'react-router-dom';

export default function ModulePlaceholder({ base, modules }) {
  const { slug } = useParams();
  const mod = modules.find((m) => m.slug === slug);
  if (!mod) return <div className="empty-state"><h1 className="h4">Page not found</h1><Link to={`${base}/dashboard`}>Back to dashboard</Link></div>;
  return (
    <div className="mx-auto" style={{ maxWidth: 640 }}>
      <div className="empty-state bg-white">
        <div className="icon-bubble ib-lav mx-auto mb-3"><i className={`bi ${mod.icon}`} /></div>
        <span className="later-badge">Coming in a later phase</span>
        <h1 className="h3 mt-3">{mod.label}</h1>
        <p className="text-muted">{mod.blurb}</p>
        <p className="small">This feature is part of ECMS but is not built in Phase 1. No data is stored or shown here yet.</p>
        <Link to={`${base}/dashboard`} className="btn btn-ecms">Back to Dashboard</Link>
      </div>
    </div>
  );
}
