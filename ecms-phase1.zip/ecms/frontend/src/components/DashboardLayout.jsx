import { NavLink, useNavigate } from 'react-router-dom';
import Logo from './Logo.jsx';
import { useAuth } from '../auth/AuthContext.jsx';

export default function DashboardLayout({ base, modules, portalName, children }) {
  const { user, signOut } = useAuth();
  const nav = useNavigate();
  const logout = () => {
    signOut();
    nav({ DIRECT_USER: '/signin', MONITORING_PERSON: '/signin', CAREGIVER: '/caregiver/login', ADMIN: '/admin/login' }[user.role], { replace: true });
  };
  return (
    <div className="dash">
      <aside className="dash-side" aria-label={`${portalName} navigation`}>
        <div className="mb-3 px-2"><Logo to={`${base}/dashboard`} /></div>
        <p className="small text-uppercase fw-bold text-muted px-2 mb-2">{portalName}</p>
        <nav className="nav flex-column gap-1">
          <NavLink end to={`${base}/dashboard`} className="nav-link"><i className="bi bi-grid-1x2-fill" />Dashboard</NavLink>
          {modules.map((x) => <NavLink key={x.slug} to={`${base}/${x.slug}`} className="nav-link"><i className={`bi ${x.icon}`} />{x.label}</NavLink>)}
        </nav>
        <hr />
        <div className="px-2 small mb-2"><i className="bi bi-person-circle me-1" />{user.fullName}</div>
        <button className="btn btn-soft w-100" onClick={logout}><i className="bi bi-box-arrow-right me-2" />Sign Out</button>
      </aside>
      <main className="dash-main page-fade" id="main">{children}</main>
    </div>
  );
}
