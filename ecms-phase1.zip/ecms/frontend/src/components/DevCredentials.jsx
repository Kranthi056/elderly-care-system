import { API_MODE } from '../api/client.js';

export const DEMO_ACCOUNTS = {
  user: [
    { label: 'Direct User', id: 'user.demo@ecms.test', pw: 'ECMS@User123' },
    { label: 'Monitoring Person', id: 'family.demo@ecms.test', pw: 'ECMS@Family123' },
  ],
  caregiver: [
    { label: 'Approved Caregiver', id: 'caregiver.demo@ecms.test', pw: 'ECMS@Care123' },
    { label: 'Pending Caregiver', id: 'caregiver.pending@ecms.test', pw: 'ECMS@Pending123' },
  ],
  admin: [{ label: 'Admin', id: 'admin.demo@ecms.test', pw: 'ECMS@Admin123' }],
};

/** DEVELOPMENT-ONLY helper. Compiled out of production builds (import.meta.env.DEV is false there). */
export default function DevCredentials({ portal, onFill }) {
  if (!import.meta.env.DEV) return null;
  return (
    <div className="dev-box mt-4" role="note">
      <strong><i className="bi bi-tools me-1" />Development-only demo credentials</strong>
      <span className="text-muted"> ({API_MODE} mode). Not for production.</span>
      <div className="mt-1">
        {DEMO_ACCOUNTS[portal].map((a) => (
          <div key={a.id} className="mb-1">
            <span className="fw-bold">{a.label}:</span> <code>{a.id}</code> / <code>{a.pw}</code>{' '}
            <button type="button" onClick={() => onFill(a.id, a.pw)}>Fill</button>
          </div>
        ))}
      </div>
    </div>
  );
}
