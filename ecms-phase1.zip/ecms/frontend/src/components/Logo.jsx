import { Link } from 'react-router-dom';

export default function Logo({ to = '/', tagline = false }) {
  return (
    <Link to={to} className="d-flex align-items-center gap-2 text-decoration-none" aria-label="ECMS home">
      <span className="logo-mark"><i className="bi bi-heart-pulse-fill" /></span>
      <span>
        <span className="logo-text d-block lh-1">ECMS</span>
        {tagline && <small className="text-muted">Care with Love, Support with Technology.</small>}
      </span>
    </Link>
  );
}
