// Navigation structure for each portal. Phase 1 only builds the shell: every module opens a clearly labelled
// "coming in a later phase" page. Slugs are used in the URL: /<base>/<slug>.
const m = (slug, label, icon, blurb) => ({ slug, label, icon, blurb });

export const USER_MODULES = [
  m('profile', 'My Profile', 'bi-person-circle', 'View and update your personal details.'),
  m('book-service', 'Book a Service', 'bi-calendar-plus', 'Request a care service from a verified caregiver.'),
  m('appointments', 'My Appointments', 'bi-calendar2-check', 'See your upcoming and past appointments.'),
  m('tasks', 'My Daily Tasks', 'bi-check2-square', 'Your daily care tasks and reminders.'),
  m('prescriptions', 'Prescriptions', 'bi-capsule', 'Prescriptions shared with your care team.'),
  m('care-updates', 'Care Updates', 'bi-activity', 'Updates from your caregivers after visits.'),
  m('messages', 'Family Messages', 'bi-chat-heart', 'Messages with your linked family members.'),
  m('linked-people', 'Linked People', 'bi-people', 'Family members authorised to view your care.'),
  m('payments', 'Payments and History', 'bi-wallet2', 'Payment records and service history.'),
  m('notifications', 'Notifications', 'bi-bell', 'Reminders and alerts.'),
  m('feedback', 'Feedback and Complaints', 'bi-chat-square-text', 'Tell us about your experience.'),
  m('settings', 'Settings', 'bi-gear', 'Account and accessibility settings.'),
  m('talk', 'Talk to ECMS', 'bi-headset', 'Reach the ECMS support team.'),
];

export const FAMILY_MODULES = [
  m('elderly-profile', 'Linked Elderly Profile', 'bi-person-heart', 'The elderly person you are authorised to monitor.'),
  m('messages', 'Messages to Patient', 'bi-chat-heart', 'Send messages to your loved one.'),
  m('alerts', 'Alerts', 'bi-exclamation-triangle', 'Important alerts about the person you monitor.'),
  m('book-service', 'Book a Service', 'bi-calendar-plus', 'Arrange care on behalf of your loved one.'),
  m('appointments', 'Appointments', 'bi-calendar2-check', 'Upcoming appointments.'),
  m('schedule', 'Daily Care Schedule', 'bi-list-check', 'Care planned for today.'),
  m('care-updates', 'Care Updates', 'bi-activity', 'Recent updates from caregivers.'),
  m('medical', 'Medical Information', 'bi-file-medical', 'Authorised access only.'),
  m('payments', 'Payments', 'bi-wallet2', 'Payments for arranged services.'),
  m('notifications', 'Notifications', 'bi-bell', 'Reminders and alerts.'),
  m('feedback', 'Feedback', 'bi-chat-square-text', 'Share feedback with ECMS.'),
  m('settings', 'Settings and Access', 'bi-gear', 'Account and access permissions.'),
];

export const CAREGIVER_MODULES = [
  m('profile', 'My Profile', 'bi-person-badge', 'Your professional profile.'),
  m('availability', 'Availability Slots', 'bi-clock', 'Set the times you can work.'),
  m('direct-requests', 'Direct Requests', 'bi-inbox', 'Requests addressed to you.'),
  m('appointment-requests', 'Appointment Requests', 'bi-calendar-event', 'Requests waiting for your response.'),
  m('schedule', 'My Schedule', 'bi-calendar3', 'Your upcoming visits.'),
  m('customers', 'My Customers', 'bi-people', 'People you care for.'),
  m('tasks', 'Daily Tasks', 'bi-check2-square', 'Tasks for your visits.'),
  m('visit-reports', 'Visit Reports', 'bi-journal-text', 'Reports after each visit.'),
  m('feedback', 'Feedback', 'bi-chat-square-text', 'Feedback from families.'),
  m('earnings', 'My Earnings', 'bi-cash-coin', 'Your earnings summary.'),
  m('leave', 'Leave', 'bi-airplane', 'Apply for and track leave.'),
  m('notifications', 'Notifications', 'bi-bell', 'Alerts and reminders.'),
];

export const ADMIN_MODULES = [
  m('talk-requests', 'Talk-to-Us Requests', 'bi-telephone-inbound', 'Enquiries from the public site.'),
  m('care-packs', 'Care Packs', 'bi-box2-heart', 'Care pack definitions.'),
  m('users', 'Users', 'bi-people', 'Elderly users and family members.'),
  m('caregivers', 'Caregivers', 'bi-person-badge', 'Caregiver accounts and verification.'),
  m('services', 'Services', 'bi-heart-pulse', 'Service catalogue.'),
  m('problem-types', 'Problem Types', 'bi-diagram-3', 'Health problem categories.'),
  m('appointments', 'Appointments', 'bi-calendar2-check', 'All appointments.'),
  m('prescription-verification', 'Prescription Verification', 'bi-patch-check', 'Verify uploaded prescriptions.'),
  m('leave', 'Leave', 'bi-airplane', 'Caregiver leave requests.'),
  m('medical-records', 'Medical Records', 'bi-file-medical', 'Medical records.'),
  m('tasks-reports', 'Tasks and Reports', 'bi-clipboard-data', 'Care tasks and visit reports.'),
  m('payments', 'Payments', 'bi-wallet2', 'Payments overview.'),
  m('notifications', 'Notifications', 'bi-bell', 'System notifications.'),
  m('feedback', 'Feedback and Complaints', 'bi-chat-square-text', 'Feedback and complaints.'),
  m('reports-settings', 'Reports and Settings', 'bi-sliders', 'Reports and platform settings.'),
];
