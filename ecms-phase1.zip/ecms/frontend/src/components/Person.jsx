/** Original stylised illustration of a person (no real people / no copyrighted characters). */
export default function Person({ skin = '#F2C9A5', hair = '#D9D9D9', top = '#319C91', bottom = '#78A88A', style = 'short', glasses = false, accessory, size = 200 }) {
  return (
    <svg width={size} height={size * 1.25} viewBox="0 0 160 200" role="img" aria-hidden="true">
      <defs>
        <linearGradient id={`t${top}`} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={top} /><stop offset="1" stopColor={bottom} /></linearGradient>
      </defs>
      <ellipse cx="80" cy="192" rx="52" ry="7" fill="rgba(66,71,71,.15)" />
      <rect x="52" y="140" width="22" height="48" rx="10" fill="#6d7a77" /><rect x="86" y="140" width="22" height="48" rx="10" fill="#6d7a77" />
      <rect x="44" y="84" width="72" height="68" rx="28" fill={`url(#t${top})`} />
      <rect x="28" y="90" width="22" height="56" rx="11" fill={top} /><rect x="110" y="90" width="22" height="56" rx="11" fill={top} />
      <circle cx="39" cy="148" r="9" fill={skin} /><circle cx="121" cy="148" r="9" fill={skin} />
      <rect x="70" y="72" width="20" height="18" rx="8" fill={skin} />
      {style === 'bun' && <circle cx="80" cy="24" r="14" fill={hair} />}
      <circle cx="80" cy="52" r="30" fill={skin} />
      <path d={style === 'bald' ? 'M52 46 Q80 22 108 46 Q80 36 52 46Z' : 'M50 50 Q52 20 80 20 Q110 20 110 50 Q96 34 80 34 Q64 34 50 50Z'} fill={hair} />
      <circle cx="69" cy="54" r="3.2" fill="#424747" /><circle cx="91" cy="54" r="3.2" fill="#424747" />
      <path d="M70 66 Q80 75 90 66" stroke="#b5604d" strokeWidth="3.4" fill="none" strokeLinecap="round" />
      <circle cx="62" cy="63" r="5" fill="#F28C78" opacity=".35" /><circle cx="98" cy="63" r="5" fill="#F28C78" opacity=".35" />
      {glasses && <g fill="none" stroke="#424747" strokeWidth="2.4"><circle cx="69" cy="54" r="9" /><circle cx="91" cy="54" r="9" /><path d="M78 54h4" /></g>}
      {accessory === 'cross' && <g><rect x="94" y="100" width="18" height="18" rx="5" fill="#fff" /><path d="M103 104v10M98 109h10" stroke="#F28C78" strokeWidth="3.4" strokeLinecap="round" /></g>}
      {accessory === 'cardigan' && <path d="M80 90v62" stroke="#FFD8C2" strokeWidth="4" />}
    </svg>
  );
}
