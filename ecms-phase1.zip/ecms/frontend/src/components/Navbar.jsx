import { useEffect, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import Logo from './Logo.jsx';
import { useAuth, ROLE_HOME } from '../auth/AuthContext.jsx';

const LINKS = [
  ['Home', '/'], ['About Us', '/#about'], ['Our Care Approach', '/#approach'], ['For Families', '/#families'], ['Contact', '/#contact'],
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const loc = useLocation();
  const { user } = useAuth();
  useEffect(() => setOpen(false), [loc.pathname, loc.hash]);

  return (
    <nav className="navbar navbar-expand-xl ecms-nav fixed-top py-2" aria-label="Main">
      <div className="container-fluid px-3 px-xl-4">
        <Logo />
        <button className="navbar-toggler border-0 shadow-none" type="button" aria-expanded={open} aria-controls="mainNav"
          aria-label="Toggle navigation" onClick={() => setOpen((o) => !o)}>
          <i className={`bi ${open ? 'bi-x-lg' : 'bi-list'} fs-2`} />
        </button>
        <div className={`collapse navbar-collapse ${open ? 'show' : ''}`} id="mainNav">
          <ul className="navbar-nav mx-auto mb-3 mb-xl-0">
            {LINKS.map(([label, to]) => (
              <li className="nav-item" key={label}><Link className={`nav-link ${label === 'Home' && loc.pathname === '/' && !loc.hash ? 'active' : ''}`} to={to}>{label}</Link></li>
            ))}
          </ul>
          <div className="d-flex flex-column flex-xl-row gap-2 align-items-xl-center">
            {user ? (
              <Link to={ROLE_HOME[user.role]} className="btn btn-ecms"><i className="bi bi-grid-fill me-2" />My Dashboard</Link>
            ) : (
              <>
                <NavLink to="/signin" className="nav-link"><i className="bi bi-person me-1" />User Sign In</NavLink>
                <NavLink to="/caregiver/login" className="nav-link"><i className="bi bi-heart me-1" />Caregiver Login</NavLink>
                <NavLink to="/admin/login" className="nav-link"><i className="bi bi-shield-lock me-1" />Admin Login</NavLink>
                <Link to="/signup" className="btn btn-coral">Get Started</Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
