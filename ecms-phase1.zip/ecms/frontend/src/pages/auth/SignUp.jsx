import { useEffect, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import AuthShell from './AuthShell.jsx';
import PasswordInput from '../../components/PasswordInput.jsx';
import { useAuth } from '../../auth/AuthContext.jsx';
import { api } from '../../api/client.js';

const PW_RE = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,64}$/;
const EMPTY = { fullName: '', mobile: '', email: '', password: '', confirm: '', gender: '', dateOfBirth: '', address: '', city: '', state: '', pinCode: '' };

function validate(f) {
  const e = {};
  if (f.fullName.trim().length < 2) e.fullName = 'Please enter your full name.';
  if (!/^\d{10}$/.test(f.mobile)) e.mobile = 'Enter a valid 10-digit mobile number.';
  if (f.email && !/^\S+@\S+\.\S+$/.test(f.email)) e.email = 'Enter a valid email address, or leave it blank.';
  if (!PW_RE.test(f.password)) e.password = 'Use 8+ characters with upper and lower case, a number and a symbol.';
  if (f.confirm !== f.password) e.confirm = 'Passwords do not match.';
  if (!f.dateOfBirth) e.dateOfBirth = 'Please enter your date of birth.';
  else if (new Date(f.dateOfBirth) >= new Date()) e.dateOfBirth = 'Date of birth must be in the past.';
  if (!f.address.trim()) e.address = 'Please enter your address.';
  if (!f.city.trim()) e.city = 'Please enter your city.';
  if (!f.state.trim()) e.state = 'Please enter your state.';
  if (!/^\d{6}$/.test(f.pinCode)) e.pinCode = 'PIN code must be 6 digits.';
  return e;
}

export default function SignUp() {
  const { register } = useAuth();
  const nav = useNavigate();
  const [step, setStep] = useState(1);
  const [role, setRole] = useState('');
  const [roleErr, setRoleErr] = useState(false);
  const [f, setF] = useState(EMPTY);
  const [err, setErr] = useState({});
  const [otp, setOtp] = useState('');
  const [otpInfo, setOtpInfo] = useState(null);
  const [cooldown, setCooldown] = useState(0);
  const [consent, setConsent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [serverErr, setServerErr] = useState('');
  const [result, setResult] = useState(null);
  const timer = useRef();

  useEffect(() => {
    if (cooldown <= 0) return;
    timer.current = setTimeout(() => setCooldown((c) => c - 1), 1000);
    return () => clearTimeout(timer.current);
  }, [cooldown]);

  useEffect(() => { // auto-redirect after the success animation
    if (!result) return;
    const t = setTimeout(() => nav(result.redirectTo, { replace: true }), 3500);
    return () => clearTimeout(t);
  }, [result, nav]);

  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const field = (k, label, props = {}) => (
    <div className={props.col || 'col-12'}>
      <label htmlFor={k} className="form-label">{label}</label>
      <input id={k} className={`form-control ${err[k] ? 'is-invalid' : ''}`} value={f[k]} onChange={set(k)} {...props.input} />
      <div className="invalid-feedback">{err[k]}</div>
    </div>
  );

  const next1 = () => (role ? (setRoleErr(false), setStep(2)) : setRoleErr(true));
  const next2 = (e) => {
    e.preventDefault();
    const er = validate(f); setErr(er);
    if (!Object.keys(er).length) setStep(3);
  };

  const sendOtp = async () => {
    setServerErr(''); setBusy(true);
    try { setOtpInfo(await api('/auth/otp/send', { method: 'POST', body: { mobile: f.mobile } })); setCooldown(20); setOtp(''); }
    catch (x) { setServerErr(x.message); }
    finally { setBusy(false); }
  };

  const finish = async (e) => {
    e.preventDefault();
    if (!/^\d{6}$/.test(otp)) return setServerErr('Enter the 6-digit OTP.');
    if (!consent) return setServerErr('Please accept the Terms and Privacy Policy to continue.');
    setServerErr(''); setBusy(true);
    try {
      const { confirm, ...rest } = f;
      setResult(await register({ ...rest, role, otp, consent, email: f.email || null, gender: f.gender || null }));
      setStep(4);
    } catch (x) { setServerErr(x.message); }
    finally { setBusy(false); }
  };

  return (
    <AuthShell theme="user">
      <div className="auth-card">
        {step < 4 && <div className="stepper" aria-label={`Step ${step} of 3`}>{[1, 2, 3].map((n) => <span key={n} className={step >= n ? 'on' : ''} />)}</div>}

        {step === 1 && (
          <>
            <h1 className="h2">Create Your ECMS Account</h1>
            <p className="text-muted">Let's get started with better-connected elderly care.</p>
            <h2 className="h5 mb-3">Step 1: Choose your role</h2>
            <div className="row g-3" role="radiogroup" aria-label="Choose your role">
              {[['DIRECT_USER', 'bi-person-heart', 'I am the Elderly Person', 'I want to manage my own care, appointments, tasks and reminders.'],
                ['MONITORING_PERSON', 'bi-people-fill', 'I am a Family Member / Representative', 'I want to arrange or monitor care for an elderly person.']].map(([v, ic, t, d]) => (
                <div className="col-12" key={v}>
                  <button type="button" role="radio" aria-checked={role === v} className={`role-card ${role === v ? 'selected' : ''}`} onClick={() => { setRole(v); setRoleErr(false); }}>
                    <div className="d-flex gap-3 align-items-center"><div className="icon-bubble ib-mint flex-shrink-0"><i className={`bi ${ic}`} /></div>
                      <div><div className="fw-bold">{t}</div><div className="small text-muted">{d}</div></div>
                      {role === v && <i className="bi bi-check-circle-fill text-teal fs-4 ms-auto" />}</div>
                  </button>
                </div>))}
            </div>
            {roleErr && <div className="text-danger small mt-2">Please select a role to continue.</div>}
            <button className="btn btn-ecms w-100 btn-lg mt-4" onClick={next1}>Continue</button>
            <p className="text-center mt-3 mb-0">Already have an account? <Link to="/signin" className="fw-bold">Sign In</Link></p>
          </>
        )}

        {step === 2 && (
          <form onSubmit={next2} noValidate>
            <h2 className="h4">Step 2: Personal information</h2>
            <div className="row g-3 mt-1">
              {field('fullName', 'Full Name', { input: { autoComplete: 'name' } })}
              {field('mobile', 'Mobile Number', { col: 'col-sm-6', input: { inputMode: 'numeric', maxLength: 10, autoComplete: 'tel-national' } })}
              {field('email', 'Email Address (optional)', { col: 'col-sm-6', input: { type: 'email', autoComplete: 'email' } })}
              <div className="col-sm-6"><PasswordInput id="password" label="Password" value={f.password} onChange={set('password')} error={err.password} autoComplete="new-password" /></div>
              <div className="col-sm-6"><PasswordInput id="confirm" label="Confirm Password" value={f.confirm} onChange={set('confirm')} error={err.confirm} autoComplete="new-password" /></div>
              <div className="col-sm-6"><label htmlFor="gender" className="form-label">Gender (optional)</label>
                <select id="gender" className="form-select" value={f.gender} onChange={set('gender')}><option value="">Prefer not to say</option><option>Female</option><option>Male</option><option>Other</option></select></div>
              {field('dateOfBirth', 'Date of Birth', { col: 'col-sm-6', input: { type: 'date', max: new Date().toISOString().slice(0, 10) } })}
              {field('address', 'Address', { input: { autoComplete: 'street-address' } })}
              {field('city', 'City', { col: 'col-sm-4' })}
              {field('state', 'State', { col: 'col-sm-4' })}
              {field('pinCode', 'PIN Code', { col: 'col-sm-4', input: { inputMode: 'numeric', maxLength: 6 } })}
            </div>
            <div className="d-flex gap-2 mt-4">
              <button type="button" className="btn btn-soft" onClick={() => setStep(1)}>Back</button>
              <button className="btn btn-ecms flex-grow-1">Continue</button>
            </div>
          </form>
        )}

        {step === 3 && (
          <form onSubmit={finish} noValidate>
            <h2 className="h4">Step 3: Account verification</h2>
            <p className="text-muted">Verify mobile number <strong>{f.mobile}</strong>.</p>
            {serverErr && <div className="alert alert-danger py-2" role="alert">{serverErr}</div>}
            {!otpInfo ? (
              <button type="button" className="btn btn-ecms mb-3" onClick={sendOtp} disabled={busy}>
                {busy ? <span className="spinner-border spinner-border-sm" /> : <>Send OTP</>}</button>
            ) : (
              <>
                {otpInfo.mock && (
                  <div className="dev-box mb-3" role="note"><strong><i className="bi bi-tools me-1" />Mock OTP mode (development).</strong> {otpInfo.message}
                    <div className="mt-1">Your code: <code className="fs-5">{otpInfo.mockOtp}</code> <button type="button" onClick={() => setOtp(otpInfo.mockOtp)}>Use this code</button></div></div>)}
                <label htmlFor="otp" className="form-label">Enter 6-digit OTP</label>
                <input id="otp" className="form-control otp-input mb-2" inputMode="numeric" maxLength={6} autoComplete="one-time-code" value={otp} onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))} />
                <div className="small mb-3">
                  {cooldown > 0 ? <span className="text-muted"><i className="bi bi-clock me-1" />Resend OTP in {cooldown}s</span>
                    : <button type="button" className="btn btn-link p-0 fw-bold" onClick={sendOtp} disabled={busy}>Resend OTP</button>}
                </div>
              </>
            )}
            <div className="form-check mb-4">
              <input id="consent" type="checkbox" className="form-check-input" checked={consent} onChange={(e) => setConsent(e.target.checked)} />
              <label htmlFor="consent" className="form-check-label">I agree to the <Link to="/terms" target="_blank">Terms</Link> and <Link to="/privacy" target="_blank">Privacy Policy</Link>.</label>
            </div>
            <div className="d-flex gap-2">
              <button type="button" className="btn btn-soft" onClick={() => { setStep(2); setServerErr(''); }}>Back</button>
              <button className="btn btn-ecms flex-grow-1" disabled={busy || !otpInfo}>
                {busy && otpInfo ? <><span className="spinner-border spinner-border-sm me-2" />Creating account…</> : 'Verify & Create Account'}</button>
            </div>
          </form>
        )}

        {step === 4 && result && (
          <div className="text-center py-3" aria-live="polite">
            <svg className="success-check mb-3" viewBox="0 0 100 100"><circle cx="50" cy="50" r="40" /><path d="M30 52l14 14 26-30" /></svg>
            <h1 className="h3">Welcome, {result.user.fullName.split(' ')[0]}!</h1>
            <p>{result.notice}</p>
            <p className="small text-muted">Taking you to your dashboard…</p>
            <button className="btn btn-ecms" onClick={() => nav(result.redirectTo, { replace: true })}>Go to Dashboard</button>
          </div>
        )}
      </div>
    </AuthShell>
  );
}
