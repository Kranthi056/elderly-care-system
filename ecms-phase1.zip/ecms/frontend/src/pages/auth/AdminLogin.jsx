import AuthShell from './AuthShell.jsx';
import LoginForm from '../../components/LoginForm.jsx';

function Cubes() {
  return (
    <div className="text-center" aria-hidden="true" style={{ perspective: 800 }}>
      <div style={{ display: 'inline-block', transformStyle: 'preserve-3d', animation: 'float 7s ease-in-out infinite', transform: 'rotateX(18deg) rotateY(-22deg)' }}>
        <div className="icon-bubble ib-lav mx-auto" style={{ width: 170, height: 170, fontSize: '5rem', borderRadius: 42, boxShadow: '24px 24px 0 #cfeee9, 0 30px 50px rgba(106,79,176,.2)' }}><i className="bi bi-hospital" /></div>
      </div>
      <div className="d-flex justify-content-center gap-3 mt-5">
        {['bi-shield-check', 'bi-clipboard2-pulse', 'bi-bar-chart-line'].map((i, k) => (
          <div key={i} className="icon-bubble ib-mint" style={{ animation: 'float 5s ease-in-out infinite', animationDelay: `${k * .5}s` }}><i className={`bi ${i}`} /></div>))}
      </div>
    </div>
  );
}

export default function AdminLogin() {
  return (
    <AuthShell theme="admin" illustration={<Cubes />}>
      <div className="auth-card">
        <span className="status-pill sp-ok mb-2"><i className="bi bi-lock-fill" />Secure authentication</span>
        <h1 className="h2">Hospital Administration Portal</h1>
        <p className="text-muted">Manage and coordinate elderly care services securely.</p>
        <LoginForm portal="admin" />
        <p className="small text-muted text-center mt-3 mb-0">Admin accounts are created by authorised staff only. Access attempts are rate-limited.</p>
      </div>
    </AuthShell>
  );
}
