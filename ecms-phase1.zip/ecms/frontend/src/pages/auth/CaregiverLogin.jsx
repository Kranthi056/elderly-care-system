import AuthShell from './AuthShell.jsx';
import LoginForm from '../../components/LoginForm.jsx';
import Person from '../../components/Person.jsx';

export default function CaregiverLogin() {
  return (
    <AuthShell theme="care" illustration={
      <div className="text-center"><div style={{ animation: 'float 6s ease-in-out infinite' }}>
        <Person top="#319C91" bottom="#25796F" style="bun" accessory="cross" skin="#E8B890" hair="#5b4636" size={220} /></div>
        <p className="mt-3 fw-bold text-teal"><i className="bi bi-patch-check-fill me-1" />Hospital-verified caregivers only</p></div>}>
      <div className="auth-card">
        <h1 className="h2">Caregiver Portal</h1>
        <p className="text-muted">Your professional workspace for delivering trusted elderly care.</p>
        <LoginForm portal="caregiver" />
        <p className="small text-muted text-center mt-3 mb-0">Caregiver accounts stay in <em>Pending Verification</em> until hospital approval. Caregiver registration is coming in a later phase.</p>
      </div>
    </AuthShell>
  );
}
