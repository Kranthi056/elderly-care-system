import { Link } from 'react-router-dom';
import Logo from '../../components/Logo.jsx';

/** Shared chrome for sign-in pages: themed background, illustration column, card. */
export default function AuthShell({ theme, illustration, children }) {
  return (
    <div className={`auth-wrap auth-${theme} page-fade`}>
      <div className="blob" style={{ width: 300, height: 300, background: theme === 'admin' ? 'var(--lavender)' : 'var(--peach)', top: 40, right: -60 }} />
      <div className="blob" style={{ width: 220, height: 220, background: theme === 'admin' ? '#bfe6e0' : 'var(--mint)', bottom: 20, left: -50, animationDelay: '-5s' }} />
      <header className="position-absolute top-0 start-0 w-100 py-3">
        <div className="container d-flex justify-content-between align-items-center">
          <Logo />
          <Link to="/" className="btn btn-soft btn-sm"><i className="bi bi-house me-1" />Home</Link>
        </div>
      </header>
      <div className="container position-relative">
        <div className="row align-items-center g-5 justify-content-center">
          {illustration && <div className="col-lg-5 d-none d-lg-block">{illustration}</div>}
          <div className="col-lg-6 col-xl-5">{children}</div>
        </div>
      </div>
    </div>
  );
}
