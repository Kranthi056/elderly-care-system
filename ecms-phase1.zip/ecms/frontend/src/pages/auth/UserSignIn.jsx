import { Link } from 'react-router-dom';
import AuthShell from './AuthShell.jsx';
import LoginForm from '../../components/LoginForm.jsx';
import Person from '../../components/Person.jsx';

export default function UserSignIn() {
  return (
    <AuthShell theme="user" illustration={
      <div className="text-center"><div style={{ animation: 'float 6s ease-in-out infinite' }} className="d-inline-flex gap-2 align-items-end">
        <Person top="#F28C78" bottom="#FFD8C2" glasses size={170} /><Person skin="#D9A57E" hair="#33302c" top="#8e7bd0" bottom="#E9E1FA" size={140} /></div>
        <h2 className="h3 mt-4">Welcome back to ECMS</h2><p>Your care, your comfort, your connection.</p></div>}>
      <div className="auth-card">
        <h1 className="h2">Sign In</h1>
        <p className="text-muted">For elderly users and family members / representatives.</p>
        <LoginForm portal="user" />
        <p className="text-center mt-4 mb-0">New to ECMS? <Link to="/signup" className="fw-bold">Create Account</Link></p>
      </div>
    </AuthShell>
  );
}
