import { Link } from 'react-router-dom';
import Navbar from '../../components/Navbar.jsx';
import Footer from '../../components/Footer.jsx';
import { useAuth, ROLE_HOME } from '../../auth/AuthContext.jsx';

function Page({ icon, title, children }) {
  return (
    <>
      <Navbar />
      <main className="bg-hero page-fade" style={{ minHeight: '80vh', paddingTop: '8rem', paddingBottom: '4rem' }}>
        <div className="container" style={{ maxWidth: 760 }}>
          <div className="auth-card text-center">
            <div className="icon-bubble ib-mint mx-auto mb-3"><i className={`bi ${icon}`} /></div>
            <h1 className="h3">{title}</h1>{children}
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}

export const NotFound = () => <Page icon="bi-compass" title="Page not found"><p>We couldn't find that page.</p><Link to="/" className="btn btn-ecms">Back to Home</Link></Page>;

export function AccessDenied() {
  const { user } = useAuth();
  return <Page icon="bi-shield-exclamation" title="Access denied">
    <p>Your account does not have permission to open that area.</p>
    <Link to={user ? ROLE_HOME[user.role] : '/'} className="btn btn-ecms">{user ? 'Go to my dashboard' : 'Back to Home'}</Link></Page>;
}

export const ForgotPassword = () => <Page icon="bi-key" title="Forgot your password?">
  <span className="later-badge">Coming in a later phase</span>
  <p className="mt-3">Self-service password reset is not part of Phase 1. Please contact the ECMS team for help.</p><Link to="/" className="btn btn-ecms">Back to Home</Link></Page>;

export const Privacy = () => <Page icon="bi-lock" title="Privacy Policy"><span className="later-badge">Placeholder</span>
  <p className="mt-3 text-start">This is placeholder text for Phase 1. The final privacy policy, covering how personal and health information is collected, used and shared with consent, must be reviewed by legal counsel before launch.</p></Page>;

export const Terms = () => <Page icon="bi-file-text" title="Terms and Conditions"><span className="later-badge">Placeholder</span>
  <p className="mt-3 text-start">This is placeholder text for Phase 1. Final terms of service must be reviewed by legal counsel before launch.</p></Page>;
