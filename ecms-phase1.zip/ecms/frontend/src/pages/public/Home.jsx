import { useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import Navbar from '../../components/Navbar.jsx';
import Footer from '../../components/Footer.jsx';
import Reveal from '../../components/Reveal.jsx';
import HeroScene from '../../components/HeroScene.jsx';
import { useTalkToUs } from '../../components/TalkToUs.jsx';

const FEATURES = [
  { icon: 'bi-patch-check-fill', cls: 'ib-mint', title: 'Trusted Care', pts: ['Hospital verification of caregivers.', 'Complete professional profiles.'] },
  { icon: 'bi-people-fill', cls: 'ib-peach', title: 'Family Connection', pts: ['Family members can monitor care through authorised access.', 'Communication between elderly users and linked family members.'] },
  { icon: 'bi-calendar2-heart-fill', cls: 'ib-lav', title: 'Organised Care', pts: ['Easy access to care services.', 'Appointments, tasks and care updates.'] },
];
const STEPS = [
  { icon: 'bi-person-plus-fill', title: 'Create Your Account', text: 'Sign up as an elderly person or as a family member in a few gentle steps.' },
  { icon: 'bi-link-45deg', title: 'Connect With Care', text: 'Link with the right people and care services, with permission at every step.' },
  { icon: 'bi-bell-fill', title: 'Stay Informed', text: 'Follow appointments, tasks and care updates from one calm place.' },
];

export default function Home() {
  const { open } = useTalkToUs();
  const { hash } = useLocation();

  // Scroll to #section links (e.g. /#about coming from another page)
  useEffect(() => {
    if (!hash) { window.scrollTo(0, 0); return; }
    setTimeout(() => document.getElementById(hash.slice(1))?.scrollIntoView({ behavior: 'smooth' }), 60);
  }, [hash]);

  // Subtle parallax on [data-speed] elements
  useEffect(() => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const els = [...document.querySelectorAll('[data-speed]')];
    let raf = 0;
    const on = () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(() => els.forEach((el) => { el.style.transform = `translateY(${window.scrollY * Number(el.dataset.speed)}px)`; })); };
    window.addEventListener('scroll', on, { passive: true });
    return () => { window.removeEventListener('scroll', on); cancelAnimationFrame(raf); };
  }, []);

  return (
    <>
      <Navbar />
      <main className="page-fade">
        {/* HERO */}
        <section id="home" className="section bg-hero pt-5" style={{ paddingTop: '8rem' }}>
          <div className="blob" data-speed="0.08" style={{ width: 320, height: 320, background: 'var(--peach)', top: 60, right: -80 }} />
          <div className="blob" data-speed="-0.05" style={{ width: 220, height: 220, background: 'var(--lavender)', bottom: 20, left: -60 }} />
          <div className="container position-relative">
            <div className="row align-items-center g-5 pt-5">
              <div className="col-lg-6">
                <span className="eyebrow mb-3"><i className="bi bi-heart-fill text-coral me-1" /> Care with Love, Support with Technology.</span>
                <h1 className="display-hero mt-3">Compassionate Elderly Care, <span className="grad-text">Connected by Technology.</span></h1>
                <p className="lead my-4">Helping elderly individuals receive trusted care while keeping their families informed, supported and connected.</p>
                <div className="d-flex flex-wrap gap-3 mb-4">
                  <Link to="/signup" className="btn btn-ecms btn-lg">Get Started <i className="bi bi-arrow-right ms-1" /></Link>
                  <button className="btn btn-soft btn-lg" onClick={open}>Talk to Us</button>
                </div>
                <div className="d-flex flex-wrap gap-2">
                  <span className="trust-chip"><i className="bi bi-patch-check-fill" />Hospital-Verified Caregivers</span>
                  <span className="trust-chip"><i className="bi bi-house-heart-fill" />Family-Centred Care</span>
                  <span className="trust-chip"><i className="bi bi-broadcast" />Connected Care Updates</span>
                </div>
                <p className="small text-muted mt-3 mb-0">Caregiver verification is the intended ECMS service model; hospital onboarding is still being set up.</p>
              </div>
              <div className="col-lg-6"><HeroScene /></div>
            </div>
          </div>
        </section>

        {/* ABOUT */}
        <section id="about" className="section bg-about">
          <div className="container">
            <Reveal className="text-center mx-auto mb-5" style={{ maxWidth: 720 }}>
              <span className="eyebrow mb-3">About ECMS</span>
              <h2 className="display-6 mt-3">Care That Brings Families Closer</h2>
              <p>ECMS is designed to organise elderly care services, connect elderly individuals with suitable caregivers and help authorised family members arrange or monitor care.</p>
            </Reveal>
            <div className="row g-4">
              {FEATURES.map((f, i) => (
                <Reveal key={f.title} className="col-md-4" delay={i * 120}>
                  <div className="glass-card lift p-4 h-100">
                    <div className={`icon-bubble ${f.cls} mb-3`}><i className={`bi ${f.icon}`} /></div>
                    <h3 className="h5">{f.title}</h3>
                    <ul className="ps-3 mb-0">{f.pts.map((p) => <li key={p} className="mb-1">{p}</li>)}</ul>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </section>

        {/* HOW IT WORKS */}
        <section id="approach" className="section bg-how">
          <div className="blob" data-speed="0.06" style={{ width: 260, height: 260, background: 'var(--mint)', top: 30, left: '8%' }} />
          <div className="container position-relative">
            <Reveal className="text-center mb-5"><span className="eyebrow mb-3">Our Care Approach</span><h2 className="display-6 mt-3">How ECMS Works</h2></Reveal>
            <div className="row g-4">
              {STEPS.map((s, i) => (
                <Reveal key={s.title} className="col-md-4" delay={i * 150}>
                  <div className="glass-card lift p-4 h-100 text-center">
                    <div className="step-num mx-auto mb-3">{i + 1}</div>
                    <div className="icon-bubble ib-mint mx-auto mb-3" style={{ animation: 'float 5s ease-in-out infinite', animationDelay: `${i * .6}s` }}><i className={`bi ${s.icon}`} /></div>
                    <h3 className="h5">{s.title}</h3><p className="mb-0">{s.text}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </section>

        {/* PORTALS */}
        <section id="portals" className="section bg-portals">
          <div className="container">
            <Reveal className="text-center mb-5"><span className="eyebrow mb-3">Get Started</span><h2 className="display-6 mt-3">Choose Your ECMS Portal</h2></Reveal>
            <div className="row g-4">
              <Reveal className="col-lg-4">
                <div className="portal-card pc-user"><div className="icon-bubble ib-mint mb-3"><i className="bi bi-people-fill" /></div>
                  <h3 className="h4">Family / Elderly User Portal</h3><p>Register or sign in to manage elderly care and authorised family access.</p>
                  <Link to="/signin" className="btn btn-ecms">User Portal</Link></div>
              </Reveal>
              <Reveal className="col-lg-4" delay={120}>
                <div className="portal-card pc-care"><div className="icon-bubble ib-peach mb-3"><i className="bi bi-heart-pulse-fill" /></div>
                  <h3 className="h4">Caregiver Portal</h3><p>Access your professional account and caregiver workspace.</p>
                  <Link to="/caregiver/login" className="btn btn-coral">Caregiver Login</Link></div>
              </Reveal>
              <Reveal className="col-lg-4" delay={240}>
                <div className="portal-card pc-admin"><div className="icon-bubble ib-lav mb-3"><i className="bi bi-hospital-fill" /></div>
                  <h3 className="h4">Hospital / Admin Portal</h3><p>Secure access for authorised hospital and administration staff.</p>
                  <Link to="/admin/login" className="btn btn-ecms">Admin Login</Link></div>
              </Reveal>
            </div>
          </div>
        </section>

        {/* HELP */}
        <section id="families" className="section bg-help">
          <div className="container">
            <Reveal className="glass-card p-4 p-md-5 text-center mx-auto" style={{ maxWidth: 820 }}>
              <div className="icon-bubble ib-peach mx-auto mb-3"><i className="bi bi-chat-heart-fill" /></div>
              <h2 className="display-6">Need Help Getting Started?</h2>
              <p>Not sure which care service is suitable? Our team can help your family understand the ECMS process.</p>
              <button className="btn btn-ecms btn-lg" onClick={open}>Talk to Us</button>
              <div id="contact" className="d-flex flex-wrap justify-content-center gap-4 mt-4 small">
                <span><i className="bi bi-telephone me-2" />+91 00000 00000</span>
                <span><i className="bi bi-envelope me-2" />care@ecms.example</span>
                <span><i className="bi bi-geo-alt me-2" />Hospital Campus, Your City</span>
              </div>
            </Reveal>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
