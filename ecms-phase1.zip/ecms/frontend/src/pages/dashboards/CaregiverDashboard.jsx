import DashboardLayout from '../../components/DashboardLayout.jsx';
import { ModuleTiles } from '../../components/ModuleTiles.jsx';
import { CAREGIVER_MODULES } from '../../components/modules.js';
import { useAuth } from '../../auth/AuthContext.jsx';
import useDashboard, { Loading, ErrorBox } from './useDashboard.jsx';

export default function CaregiverDashboard() {
  const { user } = useAuth();
  const { data, error, loading } = useDashboard('/caregiver/dashboard');
  const active = data?.active === true;
  return (
    <DashboardLayout base="/caregiver" modules={active ? CAREGIVER_MODULES : []} portalName="Caregiver Portal">
      <div className="dash-hero mb-4">
        <h1 className="h2">Welcome, {user.fullName}!</h1>
        {data && (active
          ? <span className="status-pill sp-ok mt-2"><i className="bi bi-patch-check-fill" />Verified by hospital</span>
          : <span className="status-pill sp-wait mt-2"><i className="bi bi-hourglass-split" />Pending Verification</span>)}
      </div>
      {loading ? <Loading /> : error ? <ErrorBox msg={error} /> : !active ? (
        <div className="empty-state bg-white">
          <div className="icon-bubble ib-peach mx-auto mb-3"><i className="bi bi-shield-lock" /></div>
          <p className="fw-bold fs-5">Your account is awaiting hospital verification. Dashboard access will be activated after approval.</p>
          <p className="text-muted mb-0">Until then you cannot receive bookings or view any patient information.</p>
        </div>
      ) : (
        <>
          <p className="small text-muted">Phase 1 preview: workspace sections below are placeholders; no bookings or patient data exist yet.</p>
          <ModuleTiles base="/caregiver" modules={CAREGIVER_MODULES} />
        </>
      )}
    </DashboardLayout>
  );
}
