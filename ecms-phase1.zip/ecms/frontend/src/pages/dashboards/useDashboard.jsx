import { useEffect, useState } from 'react';
import { api } from '../../api/client.js';
import { useAuth } from '../../auth/AuthContext.jsx';

/** Loads role-specific dashboard data. A 401/403 from the server signs the user out of the UI. */
export default function useDashboard(path) {
  const { signOut } = useAuth();
  const [state, setState] = useState({ data: null, error: '', loading: true });
  useEffect(() => {
    let live = true;
    api(path).then((data) => live && setState({ data, error: '', loading: false }))
      .catch((x) => { if (!live) return; if (x.status === 401) signOut(); setState({ data: null, error: x.message, loading: false }); });
    return () => { live = false; };
  }, [path, signOut]);
  return state;
}

export const Loading = () => <div className="page-loader"><div className="spinner-border text-teal" role="status" /><span className="ms-3">Loading your dashboard…</span></div>;
export const ErrorBox = ({ msg }) => <div className="alert alert-danger" role="alert">{msg}</div>;
