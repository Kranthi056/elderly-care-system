import { useState } from 'react';
import DashboardLayout from '../../components/DashboardLayout.jsx';
import { ModuleTiles, SummaryCard } from '../../components/ModuleTiles.jsx';
import { FAMILY_MODULES } from '../../components/modules.js';
import { useAuth } from '../../auth/AuthContext.jsx';
import useDashboard, { Loading, ErrorBox } from './useDashboard.jsx';

export default function MonitoringDashboard() {
  const { user } = useAuth();
  const { data, error, loading } = useDashboard('/monitoring/dashboard');
  const [info, setInfo] = useState(false);
  const linked = data?.linkedElderly?.length > 0;
  return (
    <DashboardLayout base="/family" modules={FAMILY_MODULES} portalName="Family Portal">
      <div className="dash-hero mb-4">
        <h1 className="h2">Welcome, {user.fullName}!</h1>
        <p className="mb-0 fs-5">Stay connected with the care of your loved ones.</p>
      </div>
      {loading ? <Loading /> : error ? <ErrorBox msg={error} /> : (
        <>
          <div className="row g-3 mb-4">
            <div className="col-lg-6">
              {linked ? <SummaryCard icon="bi-person-heart" title="Linked Elderly Person" empty="Linked profile will appear here." /> : (
                <div className="empty-state h-100">
                  <div className="icon-bubble ib-peach mx-auto mb-3"><i className="bi bi-person-heart" /></div>
                  <p className="fw-bold">Connect with your loved one's profile to start monitoring their care.</p>
                  <button className="btn btn-coral" onClick={() => setInfo((v) => !v)}>Connect Elderly Profile</button>
                  {info && <div className="alert alert-info text-start mt-3 mb-0 small" role="status">
                    <span className="later-badge">Coming in a later phase</span><br />Profile linking needs the elderly person's approval. Your account has been created, but to monitor an elderly person's care you must first connect to their profile and obtain the required authorisation. Accounts are never linked automatically.</div>}
                </div>)}
            </div>
            <div className="col-lg-6">
              <div className="glass-card p-3 h-100">
                <h3 className="h6">Pending Authorisation / Link Status</h3>
                <span className="status-pill sp-wait"><i className="bi bi-hourglass-split" />{linked ? 'Linked' : 'No approved link'}</span>
                <p className="small text-muted mt-2 mb-0">No elderly person's information is shown without an approved link and granted permissions.</p>
              </div>
            </div>
            <div className="col-md-4"><SummaryCard icon="bi-calendar2-check" title="Upcoming Appointments" empty="Available once a profile is linked." /></div>
            <div className="col-md-4"><SummaryCard icon="bi-list-check" tone="ib-peach" title="Today's Care Schedule" empty="Available once a profile is linked." /></div>
            <div className="col-md-4"><SummaryCard icon="bi-activity" tone="ib-lav" title="Recent Updates" empty="Available once a profile is linked." /></div>
          </div>
        </>
      )}
      <h2 className="h4 mb-3">Your tools</h2>
      <ModuleTiles base="/family" modules={FAMILY_MODULES} />
    </DashboardLayout>
  );
}
