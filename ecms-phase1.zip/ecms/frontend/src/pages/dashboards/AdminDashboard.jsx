import DashboardLayout from '../../components/DashboardLayout.jsx';
import { ModuleTiles } from '../../components/ModuleTiles.jsx';
import { ADMIN_MODULES } from '../../components/modules.js';
import useDashboard, { Loading, ErrorBox } from './useDashboard.jsx';

const Stat = ({ icon, label, value, tone }) => (
  <div className="glass-card p-3 d-flex align-items-center gap-3 h-100">
    <div className={`icon-bubble ${tone}`}><i className={`bi ${icon}`} /></div>
    <div><div className="h3 mb-0">{value}</div><div className="small text-muted">{label}</div></div>
  </div>
);

export default function AdminDashboard() {
  const { data, error, loading } = useDashboard('/admin/dashboard');
  return (
    <DashboardLayout base="/admin" modules={ADMIN_MODULES} portalName="Hospital Administration">
      <div className="dash-hero mb-4" style={{ background: 'linear-gradient(120deg, var(--lavender), #fff 55%, #d6efea)' }}>
        <h1 className="h2">Welcome to ECMS Administration</h1>
        <p className="mb-0">Manage and coordinate elderly care services securely.</p>
      </div>
      {loading ? <Loading /> : error ? <ErrorBox msg={error} /> : (
        <div className="row g-3 mb-4">
          <div className="col-6 col-xl-3"><Stat icon="bi-person-heart" tone="ib-mint" label="Elderly users" value={data.directUsers} /></div>
          <div className="col-6 col-xl-3"><Stat icon="bi-people" tone="ib-peach" label="Family members" value={data.monitoringPersons} /></div>
          <div className="col-6 col-xl-3"><Stat icon="bi-person-badge" tone="ib-lav" label="Caregiver accounts" value={data.caregivers} /></div>
          <div className="col-6 col-xl-3"><Stat icon="bi-telephone-inbound" tone="ib-sage" label="Talk-to-Us requests" value={data.talkToUsRequests} /></div>
        </div>
      )}
      <p className="small text-muted">Phase 1 shell: detailed admin operations arrive in a later phase.</p>
      <ModuleTiles base="/admin" modules={ADMIN_MODULES} />
    </DashboardLayout>
  );
}
