import DashboardLayout from '../../components/DashboardLayout.jsx';
import { ModuleTiles, SummaryCard } from '../../components/ModuleTiles.jsx';
import { USER_MODULES } from '../../components/modules.js';
import { useAuth } from '../../auth/AuthContext.jsx';
import useDashboard, { Loading, ErrorBox } from './useDashboard.jsx';

export default function DirectDashboard() {
  const { user } = useAuth();
  const { data, error, loading } = useDashboard('/direct/dashboard');
  return (
    <DashboardLayout base="/user" modules={USER_MODULES} portalName="Elderly User Portal">
      <div className="dash-hero mb-4">
        <h1 className="h2">Welcome, {user.fullName}!</h1>
        <p className="mb-0 fs-5">Your care, your comfort, your connection.</p>
      </div>
      {loading ? <Loading /> : error ? <ErrorBox msg={error} /> : (
        <>
          <div className="row g-3 mb-4">
            <div className="col-6 col-xl-3"><SummaryCard icon="bi-calendar2-check" title="Upcoming Appointments" empty="No appointments yet. Booking arrives in a later phase." /></div>
            <div className="col-6 col-xl-3"><SummaryCard icon="bi-check2-square" tone="ib-peach" title="Today's Tasks" empty="No tasks scheduled." /></div>
            <div className="col-6 col-xl-3"><SummaryCard icon="bi-hourglass-split" tone="ib-lav" title="Pending Requests" empty="No pending requests." /></div>
            <div className="col-6 col-xl-3"><SummaryCard icon="bi-activity" tone="ib-sage" title="Recent Care Updates" empty="No care updates yet." /></div>
          </div>
          <p className="small text-muted">Preview dashboard: no appointment, payment or medical records exist in Phase 1.</p>
        </>
      )}
      <h2 className="h4 mb-3">Everything in one place</h2>
      <ModuleTiles base="/user" modules={USER_MODULES} />
    </DashboardLayout>
  );
}
