import { mockRequest } from './mockApi.js';

export const API_MODE = import.meta.env.VITE_API_MODE === 'mock' ? 'mock' : 'api';
const TOKEN_KEY = 'ecms.token';

export const tokenStore = {
  get() {
    try { return localStorage.getItem(TOKEN_KEY) || sessionStorage.getItem(TOKEN_KEY); } catch { return null; }
  },
  set(token, remember) {
    this.clear();
    try { (remember ? localStorage : sessionStorage).setItem(TOKEN_KEY, token); } catch { /* storage blocked */ }
  },
  clear() {
    try { localStorage.removeItem(TOKEN_KEY); sessionStorage.removeItem(TOKEN_KEY); } catch { /* ignore */ }
  },
};

/** Single entry point for every call. Throws {status, error, message}. */
export async function api(path, { method = 'GET', body } = {}) {
  const token = tokenStore.get();
  if (API_MODE === 'mock') return mockRequest(path, { method, body, token });

  let res;
  try {
    res = await fetch('/api' + path, {
      method,
      headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw { status: 0, error: 'NETWORK', message: 'Cannot reach the ECMS server. Please check that the backend is running.' };
  }
  const data = await res.json().catch(() => null);
  if (!res.ok) {
    throw { status: res.status, error: data?.error || 'ERROR', message: data?.message || 'Something went wrong. Please try again.' };
  }
  return data;
}
