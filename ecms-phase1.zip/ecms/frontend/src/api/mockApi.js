// DEV/DEMO ONLY – browser-side mock of the backend contract (VITE_API_MODE=mock).
// It exists so the UI can be exercised without Spring Boot. It is NOT secure: users live in localStorage and
// route "protection" is frontend-only. The real RBAC lives in the Spring Boot backend.
const USERS_KEY = 'ecms.mock.users';
const OTP = new Map();

async function sha(text) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode('ecms-mock:' + text));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

const DEMO = [
  ['Asha Raman', '9000000001', 'user.demo@ecms.test', 'ECMS@User123', 'DIRECT_USER', null],
  ['Rahul Raman', '9000000002', 'family.demo@ecms.test', 'ECMS@Family123', 'MONITORING_PERSON', null],
  ['Meera Nair', '9000000003', 'caregiver.demo@ecms.test', 'ECMS@Care123', 'CAREGIVER', 'APPROVED'],
  ['Pending Caregiver', '9000000004', 'caregiver.pending@ecms.test', 'ECMS@Pending123', 'CAREGIVER', 'PENDING_VERIFICATION'],
  ['ECMS Administrator', '9000000005', 'admin.demo@ecms.test', 'ECMS@Admin123', 'ADMIN', null],
];

async function load() {
  let users = [];
  try { users = JSON.parse(localStorage.getItem(USERS_KEY) || '[]'); } catch { users = []; }
  if (!users.length) {
    users = await Promise.all(DEMO.map(async ([fullName, mobile, email, pw, role, verificationStatus], i) => ({
      id: i + 1, fullName, mobile, email, role, verificationStatus, passwordHash: await sha(pw),
    })));
    save(users);
  }
  return users;
}
const save = (u) => localStorage.setItem(USERS_KEY, JSON.stringify(u));
const view = ({ passwordHash, ...rest }) => rest;
const fail = (status, error, message) => Promise.reject({ status, error, message });
const redirectFor = (u) => ({ DIRECT_USER: '/user/dashboard', MONITORING_PERSON: '/family/dashboard', CAREGIVER: '/caregiver/dashboard', ADMIN: '/admin/dashboard' }[u.role]);
const delay = (ms = 450) => new Promise((r) => setTimeout(r, ms));

export async function mockRequest(path, { method = 'GET', body, token } = {}) {
  await delay();
  const users = await load();
  const current = () => {
    const id = token && token.startsWith('mock.') ? Number(token.slice(5)) : null;
    return users.find((u) => u.id === id);
  };
  const login = async (roles) => {
    const key = body.identifier.trim().toLowerCase();
    const u = users.find((x) => x.mobile === key || (x.email || '').toLowerCase() === key);
    if (!u || !roles.includes(u.role) || u.passwordHash !== (await sha(body.password))) {
      return fail(401, 'BAD_CREDENTIALS', "We couldn't sign you in with those details. Please check them and try again.");
    }
    const pending = u.role === 'CAREGIVER' && u.verificationStatus !== 'APPROVED';
    return {
      token: 'mock.' + u.id, user: view(u), redirectTo: redirectFor(u),
      notice: pending ? 'Your account is awaiting hospital verification. Dashboard access will be activated after approval.' : null,
    };
  };

  switch (`${method} ${path}`) {
    case 'POST /auth/otp/send': {
      const code = String(Math.floor(Math.random() * 1e6)).padStart(6, '0');
      OTP.set(body.mobile, code);
      return { mock: true, message: 'DEVELOPMENT MOCK OTP MODE: no SMS was sent. Use the code shown below.', mockOtp: code, expiresInSeconds: 120 };
    }
    case 'POST /auth/register': {
      if (!['DIRECT_USER', 'MONITORING_PERSON'].includes(body.role)) return fail(400, 'ROLE_NOT_ALLOWED', 'Role not allowed.');
      if (users.some((u) => u.mobile === body.mobile)) return fail(409, 'MOBILE_EXISTS', 'This mobile number is already registered. Please sign in.');
      if (OTP.get(body.mobile) !== body.otp) return fail(400, 'OTP_INVALID', 'That OTP is not correct. Please try again.');
      OTP.delete(body.mobile);
      const u = { id: Math.max(...users.map((x) => x.id)) + 1, fullName: body.fullName, mobile: body.mobile, email: body.email || null, role: body.role, verificationStatus: null, passwordHash: await sha(body.password) };
      save([...users, u]);
      return {
        token: 'mock.' + u.id, user: view(u), redirectTo: redirectFor(u),
        notice: u.role === 'MONITORING_PERSON'
          ? "Your account has been created. To monitor an elderly person's care, you must first connect to their profile and obtain the required authorisation."
          : 'Your account has been created. Welcome to ECMS.',
      };
    }
    case 'POST /auth/login': return login(['DIRECT_USER', 'MONITORING_PERSON']);
    case 'POST /auth/caregiver/login': return login(['CAREGIVER']);
    case 'POST /auth/admin/login': return login(['ADMIN']);
    case 'GET /auth/me': { const u = current(); return u ? view(u) : fail(401, 'UNAUTHENTICATED', 'Please sign in.'); }
    case 'POST /public/contact': return { message: 'Thank you. Our team will contact you soon.' };
    default: {
      const u = current();
      if (!u) return fail(401, 'UNAUTHENTICATED', 'Please sign in.');
      const area = { '/direct/dashboard': 'DIRECT_USER', '/monitoring/dashboard': 'MONITORING_PERSON', '/caregiver/dashboard': 'CAREGIVER', '/admin/dashboard': 'ADMIN' }[path];
      if (!area) return fail(404, 'NOT_FOUND', 'Not found.');
      if (u.role !== area) return fail(403, 'FORBIDDEN', 'You do not have permission to access this area.');
      if (area === 'MONITORING_PERSON') return { name: u.fullName, linkStatus: 'NOT_LINKED', linkedElderly: [] };
      if (area === 'CAREGIVER') return { name: u.fullName, verificationStatus: u.verificationStatus, active: u.verificationStatus === 'APPROVED' };
      if (area === 'ADMIN') return { name: u.fullName, directUsers: users.filter((x) => x.role === 'DIRECT_USER').length, monitoringPersons: users.filter((x) => x.role === 'MONITORING_PERSON').length, caregivers: users.filter((x) => x.role === 'CAREGIVER').length, talkToUsRequests: 0 };
      return { name: u.fullName };
    }
  }
}
