import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from './AuthContext.jsx';

const LOGIN_FOR = { DIRECT_USER: '/signin', MONITORING_PERSON: '/signin', CAREGIVER: '/caregiver/login', ADMIN: '/admin/login' };

/** Frontend guard (UX only). The backend independently enforces roles on every /api route. */
export default function ProtectedRoute({ roles, children }) {
  const { user, loading } = useAuth();
  const loc = useLocation();
  if (loading) return <div className="page-loader"><div className="spinner-border text-teal" role="status" /><span className="ms-3">Checking your session…</span></div>;
  if (!user) return <Navigate to={LOGIN_FOR[roles[0]]} replace state={{ from: loc.pathname }} />;
  if (!roles.includes(user.role)) return <Navigate to="/access-denied" replace />;
  return children;
}
