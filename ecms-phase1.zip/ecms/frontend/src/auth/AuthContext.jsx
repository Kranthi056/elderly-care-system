import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { api, tokenStore } from '../api/client.js';

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

/** Which sign-in page and dashboard belongs to each role. */
export const ROLE_HOME = {
  DIRECT_USER: '/user/dashboard',
  MONITORING_PERSON: '/family/dashboard',
  CAREGIVER: '/caregiver/dashboard',
  ADMIN: '/admin/dashboard',
};

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(!!tokenStore.get());

  // Re-validate any stored token with the server; the server is the source of truth for identity + role.
  useEffect(() => {
    if (!tokenStore.get()) return;
    api('/auth/me').then(setUser).catch(() => tokenStore.clear()).finally(() => setLoading(false));
  }, []);

  const establish = useCallback((res, remember = false) => {
    tokenStore.set(res.token, remember);
    setUser(res.user);
    return res;
  }, []);

  const signIn = useCallback(async (portal, form) => {
    const path = { user: '/auth/login', caregiver: '/auth/caregiver/login', admin: '/auth/admin/login' }[portal];
    return establish(await api(path, { method: 'POST', body: form }), form.remember);
  }, [establish]);

  const register = useCallback(async (form) => establish(await api('/auth/register', { method: 'POST', body: form })), [establish]);

  const signOut = useCallback(() => { tokenStore.clear(); setUser(null); }, []);

  const value = useMemo(() => ({ user, loading, signIn, register, signOut }), [user, loading, signIn, register, signOut]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
