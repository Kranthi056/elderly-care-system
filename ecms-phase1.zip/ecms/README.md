# ECMS – Phase 1 (Home, Authentication, Initial Dashboards)

**Elderly Care Management System** · *Care with Love, Support with Technology.*

Stack: **React 18 (Vite) + Bootstrap 5** frontend · **Spring Boot 3.3 (Java 17+) + Spring Security (JWT) + Hibernate/JPA** backend · **H2** (default) or **MySQL**.

Phase 1 only: public home page, shared User sign-up/sign-in, Caregiver login, Admin login, and four role-based dashboard landing shells.
Not built (later phases): booking, matching, verification workflows, medical records, prescriptions, reminders, SOS, messaging, payments, earnings, task management, analytics.

## Run locally

Prerequisites: JDK 17+, Maven 3.9+, Node 18+.

```bash
# 1) Backend  (http://localhost:8080)
cd backend
mvn spring-boot:run

# 2) Frontend (http://localhost:5173)  – new terminal
cd frontend
cp .env.example .env
npm install
npm run dev
```
Open http://localhost:5173. The Vite dev server proxies `/api` to the backend.

**No backend?** Set `VITE_API_MODE=mock` in `frontend/.env` for a browser-only mock of the same API (dev/demo only, NOT secure).

**MySQL:** create nothing manually, then `mvn spring-boot:run -Dspring-boot.run.profiles=mysql` (env: `ECMS_DB_URL`, `ECMS_DB_USER`, `ECMS_DB_PASSWORD`). Hibernate creates tables (`ddl-auto=update`).

**Tests:** `cd backend && mvn test` (RBAC matrix, wrong-portal login, pending caregiver, registration/OTP rules).

## Development-only demo accounts
Seeded at startup (BCrypt-hashed) only when `ecms.seed-demo=true` (default locally, `false` under `prod` profile). Also shown by a helper on the login pages, which is compiled out of production builds.

| Portal | Login | Password |
|---|---|---|
| Direct User | user.demo@ecms.test | ECMS@User123 |
| Monitoring Person | family.demo@ecms.test | ECMS@Family123 |
| Approved Caregiver | caregiver.demo@ecms.test | ECMS@Care123 |
| Pending Caregiver | caregiver.pending@ecms.test | ECMS@Pending123 |
| Admin | admin.demo@ecms.test | ECMS@Admin123 |

Mobiles for these accounts: 9000000001–9000000005. **Change or remove before any real use.**

## Security design
- Roles enforced **in the backend** (`SecurityConfig`): `/api/direct/**`, `/api/monitoring/**`, `/api/caregiver/**`, `/api/admin/**` each require their own role; everything else is denied by default. React route guards are UX only.
- JWT is validated per request and the user/role is re-read from the DB (role is never trusted from the token).
- Separate login endpoints per portal; a valid account used on the wrong portal gets the same generic error. 5 failed attempts lock an identifier for 5 minutes.
- Register endpoint only accepts `DIRECT_USER` / `MONITORING_PERSON`; no public admin or caregiver registration.
- Monitoring Persons are never auto-linked; their dashboard API returns no elderly data.
- Unverified caregivers get a status-only response (no requests, schedule or patient data).
- Secrets via env vars: `ECMS_JWT_SECRET`, `ECMS_DB_*`, `ECMS_CORS_ORIGINS`. Use `--spring.profiles.active=prod` (disables seeding and mock OTP, requires `ECMS_JWT_SECRET`).
- OTP is **mock mode only** (no SMS provider): the code is returned in the response and clearly labelled. Plug a real SMS gateway into `OtpService.send` later.

## Structure
```
ecms/
├─ backend/  (config, security, model, repo, dto, service, web, seed)
│  └─ src/main/resources/application*.properties
└─ frontend/src/
   ├─ api/ (client, mockApi)   ├─ auth/ (AuthContext, ProtectedRoute)
   ├─ components/ (Navbar, Footer, HeroScene, LoginForm, DashboardLayout, modules.js …)
   ├─ pages/public · pages/auth · pages/dashboards
   └─ styles/theme.css
```
Later phases: add modules to `components/modules.js`, new controllers under the role prefixes, and new entities; auth needs no rewrite.

## Notes
- Illustrations are original SVG/CSS-3D (no stock photos bundled); drop real photography into `frontend/public` when licensed.
- Privacy Policy, Terms and contact details are placeholders.
